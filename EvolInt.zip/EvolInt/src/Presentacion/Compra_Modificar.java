package Presentacion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.table.DefaultTableModel;

public class Compra_Modificar extends JFrame {

	private JPanel contentPane;
	private JTextField txtCedula;
	private JTextField txtMonto;
	private JTable Tabla;
	private JPanel jpanelFechayHora;
	

	
	 private static boolean esNumerico(String cadena) {
	        try {
	            Integer.parseInt(cadena);
	            return true;
	        } catch (NumberFormatException e) {          
	        	return false;
	        }
	    
	 }
	 
	 private static boolean esDecimal(String cadena) {
	        try {
	            Double.parseDouble(cadena);
	        	return true;
	        } catch (NumberFormatException e) {          
	        	return false;
	        }
	    
	 }
	 
	 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Compra_Modificar frame = new Compra_Modificar();
					frame.setVisible(true);
					 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Compra_Modificar() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Compra_Registrar.class.getResource("/Presentacion/imagenes/Compra.png")));
		setTitle("Modificar compra");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1037, 682);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(Compra_Registrar.class.getResource("/Presentacion/imagenes/logo.png")));
		lblLogo.setBounds(21, 31, 150, 38);
		contentPane.add(lblLogo);
		
		JLabel lblModificarCompra = new JLabel("Modificar Compra");
		lblModificarCompra.setHorizontalAlignment(SwingConstants.CENTER);
		lblModificarCompra.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblModificarCompra.setBounds(181, 40, 101, 15);
		contentPane.add(lblModificarCompra);
		TitledBorder Cedula = BorderFactory.createTitledBorder("Cedula");
		Cedula.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Cedula.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13)));
		
		jpanelFechayHora = new JPanel();
		jpanelFechayHora.setForeground(new Color(255, 128, 0));
		jpanelFechayHora.setBackground(Color.WHITE);
		jpanelFechayHora.setBounds(622, 123, 381, 68);
		contentPane.add(jpanelFechayHora);
		jpanelFechayHora.setBorder(javax.swing.BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 135, 13)),"Fecha y Hora"));
		jpanelFechayHora.setLayout(null);
		
		JLabel FechayHora = new JLabel("New label");
		FechayHora.setBounds(143, 30, 121, 14);
		jpanelFechayHora.add(FechayHora);

        SimpleDateFormat formatoHora = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        Timer timer = new Timer(1000, e -> {
           
            Date horaActual = new Date();
        
            String horaFormateada = formatoHora.format(horaActual);
            FechayHora.setText(horaFormateada);
        });

        timer.start();
		
		JPanel jpanelCliente = new JPanel();
		jpanelCliente.setForeground(new Color(255, 128, 0));
		jpanelCliente.setBackground(Color.WHITE);
		jpanelCliente.setBounds(21, 123, 591, 68);
		contentPane.add(jpanelCliente);
		jpanelCliente.setBorder(javax.swing.BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 135, 13)),"Datos de Cliente"));
		jpanelCliente.setLayout(null);
		
		txtCedula = new JTextField();
		txtCedula.setBounds(16, 33, 151, 18);
		jpanelCliente.add(txtCedula);
		txtCedula.setBackground(Color.WHITE);
		txtCedula.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtCedula.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtCedula.setColumns(10);
		
		JPanel panelCedula = new JPanel();
		panelCedula.setBackground(Color.WHITE);
		panelCedula.setBounds(10, 20, 163, 37);
		jpanelCliente.add(panelCedula);
		
		panelCedula.setBorder(Cedula);
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(299, 30, 72, 23);
		jpanelCliente.add(btnBuscar);
		
		JLabel lblNombreCompleto = new JLabel("");
		lblNombreCompleto.setBounds(386, 28, 183, 23);
		jpanelCliente.add(lblNombreCompleto);
		lblNombreCompleto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 15));
		
		JButton btnNueva = new JButton("Nuevo Cliente");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
				String usuario = "root";
			    String contrasena = "";      
				
				try {
					
					Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
					Statement statement = (Statement) conexion.createStatement();
		            String consulta = "SELECT nombre, apellido FROM cliente WHERE cedula = " + Integer.parseInt(txtCedula.getText());
		           
		         
		            ResultSet resultSet = statement.executeQuery(consulta);
		            
		            
		            int cant_filas=0;
		            String nombre=null;
		            String apellido=null;

		            
		            while(resultSet.next()){
		            	nombre=resultSet.getString("nombre");
		            	apellido=resultSet.getString("apellido");
		            	cant_filas++;
		            }
		            
		            String consulta2 = "SELECT producto, precio FROM cliente WHERE cedula = " + Integer.parseInt(txtCedula.getText());
		            ResultSet resultSet2 = statement.executeQuery(consulta2);
		            
		            
		            statement.close();
		            conexion.close();
		            
		            if(cant_filas>0) {
		            	String nombre_completo=nombre + " " + apellido;
		            	lblNombreCompleto.setText(nombre_completo);
		            	txtCedula.setEnabled(false);
		            	btnBuscar.setEnabled(false);
		            	btnNueva.setEnabled(true);
		            	
		            }else {
		            	JOptionPane.showMessageDialog(null, "El cliente no existe.", "Cliente no existe", JOptionPane.INFORMATION_MESSAGE);
		            	txtCedula.setText("");
		            }
		            
		            
		            
		            
		        } catch (SQLException e1) {
		        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
		        }
				
				
			}
		});
		
		btnBuscar.setBackground(Color.BLACK);
		btnBuscar.setForeground(Color.WHITE);
		btnBuscar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		
		//Declaro los botones
				
				btnNueva.setBounds(177, 30, 116, 23);
				jpanelCliente.add(btnNueva);
				btnNueva.setForeground(Color.WHITE);
				btnNueva.setBackground(Color.BLACK);
				btnNueva.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
				
								btnNueva.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										
										txtCedula.setEnabled(true);
						            	btnBuscar.setEnabled(true);
						            	btnNueva.setEnabled(false);
						            	lblNombreCompleto.setText("");
										txtCedula.setText("");
									}
								});
								btnNueva.setEnabled(false);

		JPanel jpanelDatosVenta = new JPanel();
		jpanelDatosVenta.setBackground(Color.WHITE);
		jpanelDatosVenta.setBounds(21, 215, 591, 289);
		contentPane.add(jpanelDatosVenta);
		jpanelDatosVenta.setBorder(javax.swing.BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 135, 13)),"Datos de compra"));;
		jpanelDatosVenta.setLayout(null);
		
		txtMonto = new JTextField();
		txtMonto.setBackground(Color.WHITE);
		txtMonto.setHorizontalAlignment(SwingConstants.RIGHT);
		txtMonto.setText("0.00");
		txtMonto.setBounds(73, 150, 151, 18);
		jpanelDatosVenta.add(txtMonto);
		txtMonto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtMonto.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtMonto.setColumns(10);
		
		TitledBorder Monto = BorderFactory.createTitledBorder("Monto");
		Monto.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Monto.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13)));
	
		JEditorPane editorPane_Descripcion = new JEditorPane();
		editorPane_Descripcion.setBackground(Color.WHITE);
		editorPane_Descripcion.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		editorPane_Descripcion.setBounds(277, 54, 262, 156);
		jpanelDatosVenta.add(editorPane_Descripcion);
		
		JComboBox comboBox_Producto = new JComboBox();
		comboBox_Producto.setModel(new DefaultComboBoxModel(new String[] {""}));
		comboBox_Producto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		comboBox_Producto.setBounds(73, 94, 151, 23);
		jpanelDatosVenta.add(comboBox_Producto);
		comboBox_Producto.setUI(new BasicComboBoxUI() {
            public void installUI(JComponent c) {
                super.installUI(c);
                comboBox_Producto.setBorder(BorderFactory.createEmptyBorder());
            }
        });
		TitledBorder Producto = BorderFactory.createTitledBorder("Producto");
		Producto.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Producto.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		JScrollPane scrollPane_Tabla = new JScrollPane();
		scrollPane_Tabla.setBounds(627, 215, 376, 289);
		scrollPane_Tabla.setBackground(Color.WHITE);
		scrollPane_Tabla.setBorder(javax.swing.BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 135, 13)),"Tabla"));

		contentPane.add(scrollPane_Tabla);
		
		DefaultTableModel modelo = new DefaultTableModel();
		JTable Tabla = new JTable(modelo);
		Tabla.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		Tabla.setBackground(Color.WHITE);
		
		modelo.addColumn("Producto");
		modelo.addColumn("Descripción");
		modelo.addColumn("Monto");
		
		scrollPane_Tabla.setViewportView(Tabla);
		
		JPanel panel_Total = new JPanel();
		panel_Total.setBackground(Color.WHITE);
		panel_Total.setBounds(627, 501, 376, 38);
		contentPane.add(panel_Total);
		panel_Total.setBorder(javax.swing.BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))));;
		panel_Total.setLayout(null);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 15));
		lblTotal.setBounds(247, 0, 44, 38);
		panel_Total.add(lblTotal);
		
		JLabel lblSumaTotal = new JLabel("0.00");
		lblSumaTotal.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 15));
		lblSumaTotal.setBounds(284, 0, 87, 38);
		panel_Total.add(lblSumaTotal);
		lblSumaTotal.setHorizontalAlignment(SwingConstants.RIGHT);
		
		
		
		JButton btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//Validacion Numerica de Cedula
	            if (esNumerico(txtCedula.getText())){
	            // Si Cedula es mayor a 1000000 y menor a 70000000
	            	if (Integer.parseInt(txtCedula.getText())>1000000 && Integer.parseInt(txtCedula.getText())<70000000){ 
	            		
	            		if (esDecimal(txtMonto.getText())){
	            			
	            			if(comboBox_Producto.getSelectedIndex()>0) {
	            				            				
	            				String producto = (String) comboBox_Producto.getSelectedItem();
	            				String descripcion = editorPane_Descripcion.getText();
	            				Double monto = Double.parseDouble(txtMonto.getText());
	            				
	            				modelo.addRow(new Object[] {producto, descripcion, monto});
	            				
	            				//Limpio los controles
	            				txtMonto.setText("0.00");
			               		editorPane_Descripcion.setText("");
			               		comboBox_Producto.setSelectedIndex(0);
	            				//ACA FALTARIA LA SUMA PARA MOSTRAR EL TOTAL
	            				
			               		Double sumaTotal=Double.parseDouble(lblSumaTotal.getText()) + monto;
			               		lblSumaTotal.setText(String.valueOf(sumaTotal));
	            			
	            			}else {
	            				JOptionPane.showMessageDialog(null, "Error debe seleccionar un producto", "Error", JOptionPane.ERROR_MESSAGE);
	            				txtMonto.setText("0.00");
		                   		editorPane_Descripcion.setText("");
		                   		comboBox_Producto.setSelectedIndex(0);
	            			}
			               		
	            		}else {
	            			JOptionPane.showMessageDialog(null, "Error en el monto, no es numerico", "Error monto", JOptionPane.ERROR_MESSAGE);
	                   		txtMonto.setText("0.00");
	                   		editorPane_Descripcion.setText("");
	                   		comboBox_Producto.setSelectedIndex(0);
	                   		
	            		}
	            		
	            	}else {
	            		JOptionPane.showMessageDialog(null, "Error la cedula no es valida", "Error", JOptionPane.ERROR_MESSAGE);
	               		txtMonto.setText("0.00");
	               		editorPane_Descripcion.setText("");
	               		comboBox_Producto.setSelectedIndex(0);
	            	}
	            		
	            }else {
	            	JOptionPane.showMessageDialog(null, "Error en la cedula, no es numerica", "Error cedula", JOptionPane.ERROR_MESSAGE);
               		txtMonto.setText("0.00");
               		editorPane_Descripcion.setText("");
               		comboBox_Producto.setSelectedIndex(0);
	        }
			    	   
			}
			
		});
		btnAgregar.setMnemonic('A');
		btnAgregar.setForeground(Color.WHITE);
		btnAgregar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnAgregar.setBackground(Color.BLACK);
		btnAgregar.setBounds(308, 221, 89, 23);
		jpanelDatosVenta.add(btnAgregar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtMonto.setText("0.00");
           		editorPane_Descripcion.setText("");
           		comboBox_Producto.setSelectedIndex(0);
           		lblSumaTotal.setText("0.00");
           		
			}
		});
		btnCancelar.setBounds(424, 221, 89, 23);
		jpanelDatosVenta.add(btnCancelar);
		btnCancelar.setForeground(Color.WHITE);
		btnCancelar.setBackground(new Color(255, 135, 13));
		btnCancelar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnCancelar.setMnemonic('C');
		
		JPanel panelProducto = new JPanel();
		panelProducto.setBackground(Color.WHITE);
		panelProducto.setBounds(67, 81, 163, 41);
		jpanelDatosVenta.add(panelProducto);
		
		panelProducto.setBorder(Producto);
		
		JPanel panelMonto = new JPanel();
		panelMonto.setBackground(Color.WHITE);
		panelMonto.setBounds(67, 137, 163, 37);
		jpanelDatosVenta.add(panelMonto);
		
		panelMonto.setBorder(Monto);
		
		JPanel panelDescripcion = new JPanel();
		panelDescripcion.setBackground(Color.WHITE);
		panelDescripcion.setBounds(266, 39, 279, 177);
		jpanelDatosVenta.add(panelDescripcion);
		TitledBorder Descripcion = BorderFactory.createTitledBorder("Descripcion");
		Descripcion.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Descripcion.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		panelDescripcion.setBorder(Descripcion);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		        String usuario = "root";
		        String contrasena = "";        
		        
				try {
					
		            Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
		            Statement statement = (Statement) conexion.createStatement();
		            //recorro la tabla
		            for(int fila=0; fila < modelo.getRowCount(); fila++) {
		            	String producto = (String) modelo.getValueAt(fila, 0);
		            	String descripcion = (String) modelo.getValueAt(fila, 1);
		            	Double monto = (Double) modelo.getValueAt(fila, 2);
		            
		            	//Obtengo ID de Producto
		            	String consultaSelect = "SELECT id FROM producto WHERE nombre = '" + producto +"'";
		            	ResultSet resultSet = statement.executeQuery(consultaSelect);
		            	int id_producto=0;
		            	while(resultSet.next()) {
			            	id_producto = resultSet.getInt("id");
			            }
			
		           //Hago INSERT 
		        		//Llamo nuevamente a now y le paso el formato
		        		int cedula=Integer.parseInt(txtCedula.getText());
		            	 
    					String consulta = "INSERT INTO compra VALUES (?, ?, NOW(), ?, ?)";
    					PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
		            	
    					preparedStatement.setInt(1, cedula);
    					preparedStatement.setInt(2, id_producto);
    					preparedStatement.setDouble(3, monto);
    					preparedStatement.setString(4, descripcion);

    					int filasInsertadas = preparedStatement.executeUpdate();
    					
    					preparedStatement.close();
		            	
		            }
		        
		            conexion.close();
		            
		            	JOptionPane.showMessageDialog(null, "Datos insertados exitosamente.");
		            	modelo.setRowCount(0);
		            	lblSumaTotal.setText("0.00");
		            	
		        } catch (SQLException e1) {
		        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
		        }		
		       
			}
		});
		btnConfirmar.setBounds(914, 550, 89, 23);
		contentPane.add(btnConfirmar);
		btnConfirmar.setForeground(Color.WHITE);
		btnConfirmar.setBackground(Color.BLACK);
		btnConfirmar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 66, 1001, 19);
		contentPane.add(panel_NegroArriba);
		
		JSeparator separator_Titulo = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo.setForeground(new Color(255, 135, 13));
		separator_Titulo.setBackground(new Color(255, 135, 13));
		separator_Titulo.setBounds(173, 29, 2, 36);
		contentPane.add(separator_Titulo);
		
		JPanel panel_NegroArriba_1 = new JPanel();
		panel_NegroArriba_1.setLayout(null);
		panel_NegroArriba_1.setBackground(Color.BLACK);
		panel_NegroArriba_1.setBounds(10, 613, 1001, 19);
		contentPane.add(panel_NegroArriba_1);
		
		//Cargo los productos
		
		String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		String usuario = "root";
	    String contrasena = "";      
		
		try {
			
			Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
			Statement statement = (Statement) conexion.createStatement();
            String consulta = "SELECT nombre FROM producto ORDER BY nombre ASC";
           
            ResultSet resultSet = statement.executeQuery(consulta);
            
            
            int cant_filas=0;
            while(resultSet.next()){
            	String producto=resultSet.getString("nombre");
            	comboBox_Producto.addItem(producto);
            	cant_filas++;
            }
            statement.close();
            conexion.close();
            if (cant_filas==0) {
            	JOptionPane.showMessageDialog(null, "No existen productos en la Base de Datos");
            }
		}
		catch (SQLException e1) {
        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
        }
	
	
		}		
}
	