package Presentacion;

import java.awt.EventQueue;




import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import com.mysql.jdbc.StringUtils;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JLayeredPane;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JPasswordField;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.plaf.basic.BasicComboBoxUI;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.Font;

import javax.swing.JOptionPane;

public class Usuario_Registrar extends JFrame {

	private JPanel contentPane;
	private JTextField txtCedula;
	private JTextField txtNombre;
	private JPasswordField txtContraseña;

	/**
	 * Launch the application.
	 */
	
	
	 private static boolean esNumerico(String cadena) {
	        try {
	            Integer.parseInt(cadena);
	            return true;
	        } catch (NumberFormatException e) {          
	        	return false;
	        }
	    }
	 
	  
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Usuario_Registrar frame = new Usuario_Registrar();
					frame.setVisible(true);
					 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	 
	
	/**
	 * Create the frame.
	 */

	
	public Usuario_Registrar() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Usuario_Registrar.class.getResource("/Presentacion/imagenes/usuario.png")));
		setTitle("Registrar usuario");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 435, 478);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		txtCedula = new JTextField();
		txtCedula.setBackground(Color.WHITE);
		txtCedula.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtCedula.setBounds(136, 119, 151, 18);
		contentPane.add(txtCedula);
		txtCedula.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtCedula.setColumns(10);
		
		JPanel panelCedula = new JPanel();
		panelCedula.setBackground(Color.WHITE);
		panelCedula.setBounds(130, 106, 163, 37);
		contentPane.add(panelCedula);
		TitledBorder Cedula = BorderFactory.createTitledBorder("Cedula");
		Cedula.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Cedula.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelCedula.setBorder(Cedula);
		getContentPane().add(panelCedula);
		
		txtNombre = new JTextField();
		txtNombre.setBackground(Color.WHITE);
		txtNombre.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtNombre.setBounds(136, 189, 151, 18);
		contentPane.add(txtNombre);
		txtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtNombre.setColumns(10);
		
		JPanel panelNombre = new JPanel();
		panelNombre.setBackground(Color.WHITE);
		panelNombre.setBounds(130, 176, 163, 37);
		contentPane.add(panelNombre);
		TitledBorder Nombre = BorderFactory.createTitledBorder("Nombre");
		Nombre.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Nombre.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelNombre.setBorder(Nombre);
		getContentPane().add(panelNombre);
		
		txtContraseña = new JPasswordField();
		txtContraseña.setBackground(Color.WHITE);
		txtContraseña.setBounds(136, 252, 151, 18);
		txtContraseña.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtContraseña);
		
		JPanel panelContraseña = new JPanel();
		panelContraseña.setBackground(Color.WHITE);
		panelContraseña.setBounds(130, 239, 163, 37);
		contentPane.add(panelContraseña);
		TitledBorder Contraseña = BorderFactory.createTitledBorder("Contraseña");
		Contraseña.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Contraseña.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelContraseña.setBorder(Contraseña);
		getContentPane().add(panelContraseña);
		
		JComboBox comboBox_Usuario = new JComboBox();
		comboBox_Usuario.setModel(new DefaultComboBoxModel(new String[] {"", "Administrador", "Usuario"}));
		comboBox_Usuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		comboBox_Usuario.setBounds(136, 314, 151, 23);
		comboBox_Usuario.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(comboBox_Usuario);
		
		comboBox_Usuario.setUI(new BasicComboBoxUI() {
            public void installUI(JComponent c) {
                super.installUI(c);
                comboBox_Usuario.setBorder(BorderFactory.createEmptyBorder());
            }
        });
		
		JPanel panelUsuario = new JPanel();
		panelUsuario.setBackground(Color.WHITE);
		panelUsuario.setBounds(130, 301, 163, 41);
		contentPane.add(panelUsuario);
		TitledBorder Usuario = BorderFactory.createTitledBorder("Usuario");
		Usuario.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Usuario.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelUsuario.setBorder(Usuario);
		getContentPane().add(panelUsuario);
		
		
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		        String usuario = "root";
		        String contrasena = "";        
		        
				try {
					
				//Validacion Numerica de Cedula
		            if (esNumerico(txtCedula.getText())){
		            // Si Cedula es mayor a 1000000 y menor a 70000000
		            	if (Integer.parseInt(txtCedula.getText())>1000000 && Integer.parseInt(txtCedula.getText())<70000000){  
		            	// Si nombre de usuario sea un largo mayor = 5
		            		if(txtNombre.getText().length()>=5) {
		            		// Contraseña mayor o igual a 8
		            			if (txtContraseña.getText().length()>=8) {
		            			// Selecciono un tipo de usuario
		            				if(comboBox_Usuario.getSelectedIndex()>0) {
		            					
		            					Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
		            					String consulta = "INSERT INTO usuario VALUES (?, ?, AES_ENCRYPT(?, 'EvolInt_Proyecto'), ?)";
		            					PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
	
		            					int cedula = Integer.parseInt(txtCedula.getText());
		            					String nombre = txtNombre.getText();
		            					String contraseña = txtContraseña.getText();
		            					String comboBox_usuario = (String) comboBox_Usuario.getSelectedItem();
			   
		            					preparedStatement.setInt(1, cedula);
		            					preparedStatement.setString(2, nombre);
		            					preparedStatement.setString(3, contraseña);
		            					preparedStatement.setString(4, comboBox_usuario);
	
		            					int filasInsertadas = preparedStatement.executeUpdate();
	
		            					if (filasInsertadas > 0) {
		            						JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente.", "Usuario creado", JOptionPane.INFORMATION_MESSAGE);
		            						txtCedula.setText("");
		            						txtNombre.setText("");
		            						txtContraseña.setText("");
		            						comboBox_Usuario.setSelectedIndex(0);
		            						
		            					} else {
		            						JOptionPane.showMessageDialog(null, " No se pudo insertar el registro.", "Error", JOptionPane.ERROR_MESSAGE);
		            					}
		            					preparedStatement.close();
			    
		            					conexion.close();
			            }else {		    
		            		JOptionPane.showMessageDialog(null, "Error debe seleccionar un tipo de usuario", "Error", JOptionPane.ERROR_MESSAGE);
				        	txtCedula.setText("");
		               		txtNombre.setText("");
		               		txtContraseña.setText("");
		               		comboBox_Usuario.setSelectedIndex(0);
		            	}
		            	}else {
		            		JOptionPane.showMessageDialog(null, "Error la contraseña debe contener 8 caracteres como minimo", "Error", JOptionPane.ERROR_MESSAGE);
				        	txtCedula.setText("");
		               		txtNombre.setText("");
		               		txtContraseña.setText("");
		               		comboBox_Usuario.setSelectedIndex(0);
		            			
		            		}
		            	}else {
		            		JOptionPane.showMessageDialog(null, "Error el nombre de usuario debe contener 5 caracteres como minimo", "Error", JOptionPane.ERROR_MESSAGE);
				        	txtCedula.setText("");
		               		txtNombre.setText("");
		               		txtContraseña.setText("");
		               		comboBox_Usuario.setSelectedIndex(0);
		            		
		            	}
		            	}else {
		            		JOptionPane.showMessageDialog(null, "Error la cedula no es valida", "Error", JOptionPane.ERROR_MESSAGE);
				        	txtCedula.setText("");
		               		txtNombre.setText("");
		               		txtContraseña.setText("");
		               		comboBox_Usuario.setSelectedIndex(0);
		            	}
		            		
		            }else {
		            	JOptionPane.showMessageDialog(null, "Error en la cedula, no es numerica", "Error cedula", JOptionPane.ERROR_MESSAGE);
			        	txtCedula.setText("");
	               		txtNombre.setText("");
	               		txtContraseña.setText("");
	               		comboBox_Usuario.setSelectedIndex(0);
		        	
		        }
		        } catch (SQLException e1) {
		        		if (e1.getMessage().contains("PRIMARY")==true) {
		        			JOptionPane.showMessageDialog(null, "Error la cédula ya se encuentra registrada.", "Error", JOptionPane.ERROR_MESSAGE);
		        			txtCedula.setText("");
		               		txtNombre.setText("");
		               		txtContraseña.setText("");
		               		comboBox_Usuario.setSelectedIndex(0);
			        	
		        		} else {
		        			if (e1.getMessage().contains("key")==true) {
			        			JOptionPane.showMessageDialog(null, "Error el nombre ya se encuentra registrado", "Error", JOptionPane.ERROR_MESSAGE);
			        			txtCedula.setText("");
			               		txtNombre.setText("");
			               		txtContraseña.setText("");
			               		comboBox_Usuario.setSelectedIndex(0);
		        			}
		        }		
		       }
			}
		});
		btnIngresar.setForeground(Color.WHITE);
		btnIngresar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnIngresar.setBackground(Color.BLACK);
		btnIngresar.setBounds(130, 363, 163, 23);
		contentPane.add(btnIngresar);
		
		JLabel lblTitulo = new JLabel("Registrar usuario");
		lblTitulo.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setBounds(188, 25, 89, 23);
		contentPane.add(lblTitulo);
		
		 JSeparator separator_Titulo = new JSeparator(SwingConstants.VERTICAL); // Crear un separador vertical
		 separator_Titulo.setForeground(new Color(255, 135, 13));
			separator_Titulo.setBackground(new Color(255, 135, 13));
			separator_Titulo.setBounds(180, 18, 2, 36);
		 contentPane.add(separator_Titulo);
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 56, 399, 19);
		contentPane.add(panel_NegroArriba);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setLayout(null);
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(10, 410, 399, 19);
		contentPane.add(panel_NegroAbajo);
		
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(Usuario_Registrar.class.getResource("/Presentacion/imagenes/logo.png")));
		lblLogo.setBounds(28, 18, 150, 43);
		contentPane.add(lblLogo);
		
		JSeparator separator_Titulo_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1.setBounds(20, 89, 2, 310);
		contentPane.add(separator_Titulo_1);
		
		JSeparator separator_Titulo_1_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBounds(395, 89, 2, 310);
		contentPane.add(separator_Titulo_1_1);
		
		
	
	}
	}


