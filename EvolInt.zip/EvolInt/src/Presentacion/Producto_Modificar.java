package Presentacion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;

public class Producto_Modificar extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtNombre;
	private JTextField txtPrecio;

	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Producto_Modificar frame = new Producto_Modificar();
					frame.setVisible(true);
					 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private static boolean esNumerico(String cadena) {
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException e) {          
        	return false;
        }
    }

	private static boolean esDecimal(String cadena) {
        try {
            Double.parseDouble(cadena);
        	return true;
        } catch (NumberFormatException e) {          
        	return false;
        }
    
 }
	
	/**
	 * Create the frame.
	 */
	public Producto_Modificar() {
		setResizable(false);
		setTitle("Modificar producto");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Producto_Registrar.class.getResource("/Presentacion/imagenes/producto.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 430, 503);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBuscar = new JButton("");
		btnBuscar.setIcon(new ImageIcon(Producto_Modificar.class.getResource("/Presentacion/imagenes/lupa.png")));
		
		JComboBox comboBox_Proveedores = new JComboBox();
		JButton btnNueva = new JButton("");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
				String usuario = "root";
			    String contrasena = "";      
				
				try {
					
					if (esNumerico(txtId.getText())){
						
						if (Integer.parseInt(txtId.getText())>0 && Integer.parseInt(txtId.getText())<999999999){
					
					Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
					Statement statement = (Statement) conexion.createStatement();
		            String consulta = "SELECT nombre, precio, rut FROM producto WHERE id = " + Integer.parseInt(txtId.getText());
		           
		            ResultSet resultSet = statement.executeQuery(consulta);
		            
		            
		            int cant_filas=0;
		            String nombre=null;
		            String precio=null;
		            String rut=null;
		            
		            
		            while(resultSet.next()){
		            	nombre=resultSet.getString("nombre");
		            	precio=resultSet.getString("precio");
		            	rut=resultSet.getString("rut");
		            	
		            	cant_filas++;
		            }
		            
		            
		            String consultaProveedor = "SELECT nombre FROM proveedor WHERE rut = " + Integer.parseInt(rut);
		            
		            ResultSet resultSet2 = statement.executeQuery(consultaProveedor);
		           String nombre_prov=null; 
		            int cant_filas_proveedor=0;
		            while(resultSet2.next()){
		            	nombre_prov=resultSet2.getString("nombre");	            	
		            	cant_filas_proveedor++;
		            }
		          
		            statement.close();
		            conexion.close();
		            
		            if(cant_filas>0) {
		        
		            	txtNombre.setText(nombre);
		            	txtPrecio.setText(precio);
		            	comboBox_Proveedores.setSelectedItem(nombre_prov);
		            	txtId.setEnabled(false);
		            	btnBuscar.setEnabled(false);
		            	btnNueva.setEnabled(true);
		            	
		            }else {
		            	JOptionPane.showMessageDialog(null, "El id no existe.", "Proveedor no existe", JOptionPane.INFORMATION_MESSAGE);
		            	txtId.setText("");
		            }
		            
		            }else {
						JOptionPane.showMessageDialog(null, "Error en el id, no es valido", "Error", JOptionPane.ERROR_MESSAGE);		        	
						txtNombre.setText("");
						txtPrecio.setText("0.00");
						comboBox_Proveedores.setSelectedIndex(0);
						
					}
			
				}else {
					JOptionPane.showMessageDialog(null, "Error en el id, no es numerico", "Error id", JOptionPane.ERROR_MESSAGE);
					txtNombre.setText("");
					txtPrecio.setText("0.00");
					comboBox_Proveedores.setSelectedIndex(0);
				}
		 
		        } catch (SQLException e1) {
		        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
		        }
				
				
			}
		});
		
		
		
		btnBuscar.setForeground(Color.WHITE);
		btnBuscar.setBackground(Color.WHITE);
		btnBuscar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnBuscar.setBounds(254, 112, 26, 23);
		contentPane.add(btnBuscar);
		
		txtId = new JTextField();
		txtId.setBackground(Color.WHITE);
		txtId.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtId.setBounds(126, 147, 151, 18);
		txtId.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		JPanel panelId = new JPanel();
		panelId.setBackground(Color.WHITE);
		panelId.setBounds(120, 134, 163, 37);
		contentPane.add(panelId);
		TitledBorder Id = BorderFactory.createTitledBorder("Id");
		Id.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Id.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelId.setBorder(Id);
		getContentPane().add(panelId);
		
		txtNombre = new JTextField();
		txtNombre.setBackground(Color.WHITE);
		txtNombre.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtNombre.setBounds(126, 208, 151, 18);
		txtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		JPanel panelNombre = new JPanel();
		panelNombre.setBackground(Color.WHITE);
		panelNombre.setBounds(120, 195, 163, 37);
		contentPane.add(panelNombre);
		TitledBorder Nombre = BorderFactory.createTitledBorder("Nombre");
		Nombre.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Nombre.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelNombre.setBorder(Nombre);
		getContentPane().add(panelNombre);
		
		txtPrecio = new JTextField();
		txtPrecio.setBackground(Color.WHITE);
		txtPrecio.setHorizontalAlignment(SwingConstants.RIGHT);
		txtPrecio.setText("0.00");
		txtPrecio.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtPrecio.setBounds(126, 272, 151, 18);
		txtPrecio.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtPrecio);
		txtPrecio.setColumns(10);
		
		JPanel panelPrecio = new JPanel();
		panelPrecio.setBackground(Color.WHITE);
		panelPrecio.setBounds(120, 259, 163, 37);
		contentPane.add(panelPrecio);
		TitledBorder Precio = BorderFactory.createTitledBorder("Precio");
		Precio.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Precio.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelPrecio.setBorder(Precio);
		getContentPane().add(panelPrecio);
		
		
		comboBox_Proveedores.setModel(new DefaultComboBoxModel(new String[] {""}));
		comboBox_Proveedores.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		comboBox_Proveedores.setBounds(126, 330, 151, 23);
		contentPane.add(comboBox_Proveedores);
		
		comboBox_Proveedores.setUI(new BasicComboBoxUI() {
            public void installUI(JComponent c) {
                super.installUI(c);
                comboBox_Proveedores.setBorder(BorderFactory.createEmptyBorder());
            }
        });
		
		JPanel panelProveedor = new JPanel();
		panelProveedor.setBackground(Color.WHITE);
		panelProveedor.setBounds(120, 317, 163, 41);
		contentPane.add(panelProveedor);
		TitledBorder Proveedor = BorderFactory.createTitledBorder("Proveedor");
		Proveedor.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Proveedor.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelProveedor.setBorder(Proveedor);
		getContentPane().add(panelProveedor);
		
		String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		String usuario = "root";
	    String contrasena = "";      
		
		try {
			
			Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
			Statement statement = (Statement) conexion.createStatement();
            String consulta = "SELECT nombre FROM proveedor ORDER BY nombre ASC" ;
           
            ResultSet resultSet = statement.executeQuery(consulta);
            
            int cant_filas=0;
            while(resultSet.next()){
            	String proveedor=resultSet.getString("nombre");
            	comboBox_Proveedores.addItem(proveedor);
            	cant_filas++;
            }
            statement.close();
            conexion.close();
            if (cant_filas==0) {
            	JOptionPane.showMessageDialog(null, "No existen proveedores en la Base de Datos");
            }
		}
		catch (SQLException e1) {
        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
        }
		
		
	
		
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(Producto_Registrar.class.getResource("/Presentacion/imagenes/logo.png")));
		lblLogo.setBounds(30, 31, 150, 40);
		contentPane.add(lblLogo);
		
		JLabel lblModificarProducto = new JLabel("Modificar Producto");
		lblModificarProducto.setHorizontalAlignment(SwingConstants.CENTER);
		lblModificarProducto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblModificarProducto.setBounds(188, 42, 102, 14);
		contentPane.add(lblModificarProducto);
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 68, 394, 19);
		contentPane.add(panel_NegroArriba);
		
		JSeparator separator_Titulo = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo.setForeground(new Color(255, 135, 13));
		separator_Titulo.setBackground(new Color(255, 135, 13));
		separator_Titulo.setBounds(180, 31, 2, 36);
		contentPane.add(separator_Titulo);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setLayout(null);
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(10, 434, 394, 19);
		contentPane.add(panel_NegroAbajo);
		
		JSeparator separator_Titulo_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1.setBounds(20, 98, 2, 325);
		contentPane.add(separator_Titulo_1);
		
		JSeparator separator_Titulo_1_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBounds(389, 98, 2, 325);
		contentPane.add(separator_Titulo_1_1);
		
		btnNueva.setIcon(new ImageIcon(Producto_Modificar.class.getResource("/Presentacion/imagenes/nueva.png")));
		btnNueva.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtId.setEnabled(true);
            	btnBuscar.setEnabled(true);
            	btnNueva.setEnabled(false);
            	txtId.setText("");
				txtNombre.setText("");
				txtPrecio.setText("");
				comboBox_Proveedores.setSelectedIndex(0);
			}
		});
		
		JButton btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		        String usuario = "root";
		        String contrasena = "";        
		        
				try {
				
				if (Integer.parseInt(txtId.getText())>0 && Integer.parseInt(txtId.getText())<999999999){
					
					if (txtNombre.getText().length()>0) {
						
						if (Double.parseDouble(txtPrecio.getText())>0 && Double.parseDouble(txtPrecio.getText())<999999999){
							
							if(comboBox_Proveedores.getSelectedIndex()>0) {
								
								//Obtengo ID de Producto
								Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
								Statement statement = (Statement) conexion.createStatement();
								
				            	String consultaSelect = "SELECT rut FROM proveedor WHERE nombre = '" + comboBox_Proveedores.getSelectedItem() +"'";
				            	ResultSet resultSet = statement.executeQuery(consultaSelect);
				            	int rut_proveedor=0;
				            	while(resultSet.next()) {
				            		rut_proveedor = resultSet.getInt("rut");
				            		
					            }
							
				            	
            					String consulta = "UPDATE producto SET nombre = ?, precio = ?, rut =?  WHERE id = " + Integer.parseInt(txtId.getText());
            					PreparedStatement preparedStatement = conexion.prepareStatement(consulta);

            					String nombre = txtNombre.getText();
            					double precio = Double.parseDouble(txtPrecio.getText());
            					
            					
	  
            					preparedStatement.setString(1, nombre);
            					preparedStatement.setDouble(2, precio);
            					preparedStatement.setInt(3, rut_proveedor);

            					int filasModificadas = preparedStatement.executeUpdate();

            					if (filasModificadas > 0) {
            						JOptionPane.showMessageDialog(null, "Producto Modificado exitosamente.", "Producto modificado", JOptionPane.INFORMATION_MESSAGE);
            						txtId.setText("");
            						txtNombre.setText("");
									txtPrecio.setText("");
									comboBox_Proveedores.setSelectedIndex(0);
            						
            					} else {
            						JOptionPane.showMessageDialog(null, "No se pudo modificar el Producto.", "Error", JOptionPane.ERROR_MESSAGE);
            					}
            					preparedStatement.close();
	    
            					conexion.close();
						
        					}else {
	            				JOptionPane.showMessageDialog(null, "Error debe seleccionar un proveedor", "Error", JOptionPane.ERROR_MESSAGE);
	            				txtId.setText("");
        						txtNombre.setText("");
        						txtPrecio.setText("0.00");
        						comboBox_Proveedores.setSelectedIndex(0);
	            			}
        					
        					
						}else {
							JOptionPane.showMessageDialog(null, "Error el precio no es valido", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
							txtId.setText("");
							txtNombre.setText("");
							txtPrecio.setText("0.00");
							comboBox_Proveedores.setSelectedIndex(0);
						}
						
					}else {
						JOptionPane.showMessageDialog(null, "Error nombre no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
						txtId.setText("");
						txtNombre.setText("");
						txtPrecio.setText("0.00");
						comboBox_Proveedores.setSelectedIndex(0);
					}
					
				}else {
					JOptionPane.showMessageDialog(null, "Error el id no es valido", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
					txtId.setText("");
					txtNombre.setText("");
					txtPrecio.setText("0.00");
					comboBox_Proveedores.setSelectedIndex(0);
				}
				
				 } catch (SQLException e1) {
					 JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					 
		        		/*if (e1.getMessage().contains("PRIMARY")==true) {
		        			JOptionPane.showMessageDialog(null, "Error el id ya se encuentra registrada.", "Error", JOptionPane.ERROR_MESSAGE);
		        			txtId.setText("");
		        		}*/	
		       }
				
			}
		});
		btnModificar.setForeground(Color.WHITE);
		btnModificar.setBackground(Color.BLACK);
		btnModificar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnModificar.setBounds(120, 385, 163, 23);
		contentPane.add(btnModificar);
		
		btnNueva.setBackground(Color.WHITE);
		btnNueva.setForeground(Color.WHITE);
		btnNueva.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnNueva.setBounds(221, 112, 26, 23);
		contentPane.add(btnNueva);
		
	}
}