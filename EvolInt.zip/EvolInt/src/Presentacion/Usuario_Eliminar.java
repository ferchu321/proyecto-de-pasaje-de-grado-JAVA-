package Presentacion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.table.DefaultTableModel;

public class Usuario_Eliminar extends JFrame {

	private JPanel contentPane;
	private JTextField txtCedula;
	private JTextField txtNombre;
	private JPasswordField txtContraseña;

	/**
	 * Launch the application.
	 */
	
	
	 private static boolean esNumerico(String cadena) {
	        try {
	            Integer.parseInt(cadena);
	            return true;
	        } catch (NumberFormatException e) {          
	        	return false;
	        }
	    }
	 
	  
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Usuario_Eliminar frame = new Usuario_Eliminar();
					frame.setVisible(true);
					 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	 
	
	/**
	 * Create the frame.
	 */

	private boolean mostrar_tabla=false;
	
	public Usuario_Eliminar() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Usuario_Registrar.class.getResource("/Presentacion/imagenes/usuario.png")));
		setTitle("Eliminar usuario");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 434, 497);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNueva = new JButton("");
		JComboBox comboBox_Usuario = new JComboBox();
		comboBox_Usuario.setEnabled(false);
		JButton btnEliminar = new JButton("Eliminar");
		JButton btnBuscar = new JButton("");
		btnBuscar.setIcon(new ImageIcon(Usuario_Modificar.class.getResource("/Presentacion/imagenes/lupa.png")));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
				String usuario = "root";
			    String contrasena = "";      
				
				try {
					
					if (esNumerico(txtCedula.getText())){
						
						if (Integer.parseInt(txtCedula.getText())>1000000 && Integer.parseInt(txtCedula.getText())<70000000){
					
					Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
					Statement statement = (Statement) conexion.createStatement();
		            String consulta = "SELECT nombre_usuario, contraseña, tipo_usuario FROM usuario WHERE cedula = " + Integer.parseInt(txtCedula.getText());
		           
		         
		            ResultSet resultSet = statement.executeQuery(consulta);
		            
		            
		            int cant_filas=0;
		            String nombre_usuario=null;
		            String contraseña=null;
		            String tipo_usuario=null;

		            
		            while(resultSet.next()){
		            	nombre_usuario=resultSet.getString("nombre_usuario");
		            	contraseña=resultSet.getString("contraseña");
		            	tipo_usuario=resultSet.getString("tipo_usuario");
		            	
		            	cant_filas++;
		            }
		     
		            statement.close();
		            conexion.close();
		            
		            if(cant_filas>0) {
		        
		            	txtNombre.setText(nombre_usuario);
		            	comboBox_Usuario.setSelectedItem(tipo_usuario);
		            	txtContraseña.setText(contraseña);
		            	txtCedula.setEnabled(false);
		            	btnBuscar.setEnabled(false);
		            	btnNueva.setEnabled(true);
		            	btnEliminar.setEnabled(true);
		            	
		            }else {
		            	JOptionPane.showMessageDialog(null, "El cliente no existe.", "Cliente no existe", JOptionPane.INFORMATION_MESSAGE);
		            	txtCedula.setText("");
		            	
		            }
		            
		            }else {
						JOptionPane.showMessageDialog(null, "Error en la cedula, no es valida", "Error", JOptionPane.ERROR_MESSAGE);		        	
						txtNombre.setText("");
						txtContraseña.setText("");
						txtCedula.setText("");
						comboBox_Usuario.setSelectedIndex(0);
					}
			
				}else {
					JOptionPane.showMessageDialog(null, "Error en la cedula, no es numerica", "Error cedula", JOptionPane.ERROR_MESSAGE);
					txtNombre.setText("");
					txtCedula.setText("");
					txtContraseña.setText("");
					comboBox_Usuario.setSelectedIndex(0);
				}
		 
		        } catch (SQLException e1) {
		        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
		        }
				
				
			}
		});
		btnBuscar.setForeground(Color.WHITE);
		btnBuscar.setBackground(Color.WHITE);
		btnBuscar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnBuscar.setBounds(172, 102, 26, 23);
		contentPane.add(btnBuscar);
		
		
		
		txtCedula = new JTextField();
		txtCedula.setBackground(Color.WHITE);
		txtCedula.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtCedula.setBounds(136, 145, 151, 18);
		contentPane.add(txtCedula);
		txtCedula.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtCedula.setColumns(10);
		
		JPanel panelCedula = new JPanel();
		panelCedula.setBackground(Color.WHITE);
		panelCedula.setBounds(130, 132, 163, 37);
		contentPane.add(panelCedula);
		TitledBorder Cedula = BorderFactory.createTitledBorder("Cedula");
		Cedula.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Cedula.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelCedula.setBorder(Cedula);
		getContentPane().add(panelCedula);
		
		txtNombre = new JTextField();
		txtNombre.setEnabled(false);
		txtNombre.setBackground(Color.WHITE);
		txtNombre.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtNombre.setBounds(136, 208, 151, 18);
		contentPane.add(txtNombre);
		txtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtNombre.setColumns(10);
		
		JPanel panelNombre = new JPanel();
		panelNombre.setBackground(Color.WHITE);
		panelNombre.setBounds(130, 195, 163, 37);
		contentPane.add(panelNombre);
		TitledBorder Nombre = BorderFactory.createTitledBorder("Nombre");
		Nombre.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Nombre.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelNombre.setBorder(Nombre);
		getContentPane().add(panelNombre);
		
		txtContraseña = new JPasswordField();
		txtContraseña.setEnabled(false);
		txtContraseña.setBackground(Color.WHITE);
		txtContraseña.setBounds(136, 271, 151, 18);
		txtContraseña.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtContraseña);
		
		JPanel panelContraseña = new JPanel();
		panelContraseña.setBackground(Color.WHITE);
		panelContraseña.setBounds(130, 258, 163, 37);
		contentPane.add(panelContraseña);
		TitledBorder Contraseña = BorderFactory.createTitledBorder("Contraseña");
		Contraseña.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Contraseña.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelContraseña.setBorder(Contraseña);
		getContentPane().add(panelContraseña);
		
		
		comboBox_Usuario.setModel(new DefaultComboBoxModel(new String[] {"", "Administrador", "Usuario"}));
		comboBox_Usuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		comboBox_Usuario.setBounds(136, 333, 151, 23);
		comboBox_Usuario.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(comboBox_Usuario);
		
		comboBox_Usuario.setUI(new BasicComboBoxUI() {
            public void installUI(JComponent c) {
                super.installUI(c);
                comboBox_Usuario.setBorder(BorderFactory.createEmptyBorder());
            }
        });
		
		JPanel panelUsuario = new JPanel();
		panelUsuario.setBackground(Color.WHITE);
		panelUsuario.setBounds(130, 321, 163, 41);
		contentPane.add(panelUsuario);
		TitledBorder Usuario = BorderFactory.createTitledBorder("Usuario");
		Usuario.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Usuario.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelUsuario.setBorder(Usuario);
		getContentPane().add(panelUsuario);
		
		
		JScrollPane scrollPane_Listado = new JScrollPane();	
		scrollPane_Listado.setVisible(false);
		scrollPane_Listado.setBounds(410, 89, 304, 328);
		scrollPane_Listado.setBackground(Color.WHITE);
		scrollPane_Listado.setBorder(javax.swing.BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))));
		contentPane.add(scrollPane_Listado);
		
		DefaultTableModel modelo = new DefaultTableModel();
		JTable Listado = new JTable(modelo);
		Listado.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		Listado.setBackground(Color.WHITE);
		
		modelo.addColumn("Cedula");
		modelo.addColumn("Nombre");
		modelo.addColumn("Contraseña");
		modelo.addColumn("Perfil");
		
		scrollPane_Listado.setViewportView(Listado);
		
		JLabel lblTitulo = new JLabel("Eliminar usuario");
		lblTitulo.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setBounds(188, 25, 94, 23);
		contentPane.add(lblTitulo);
		
		 JSeparator separator_Titulo = new JSeparator(SwingConstants.VERTICAL); // Crear un separador vertical
		 separator_Titulo.setForeground(new Color(255, 135, 13));
			separator_Titulo.setBackground(new Color(255, 135, 13));
			separator_Titulo.setBounds(180, 18, 2, 36);
		 contentPane.add(separator_Titulo);
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 56, 399, 19);
		contentPane.add(panel_NegroArriba);
		
		JLabel lblListado_1 = new JLabel("Listado de usuarios");
		lblListado_1.setBackground(new Color(240, 240, 240));
		lblListado_1.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 14));
		lblListado_1.setForeground(Color.WHITE);
		lblListado_1.setBounds(487, 0, 135, 19);
		panel_NegroArriba.add(lblListado_1);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setLayout(null);
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(10, 428, 399, 19);
		contentPane.add(panel_NegroAbajo);
		
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(Usuario_Registrar.class.getResource("/Presentacion/imagenes/logo.png")));
		lblLogo.setBounds(28, 18, 150, 43);
		contentPane.add(lblLogo);
		
		JSeparator separator_Titulo_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1.setBounds(20, 89, 2, 328);
		contentPane.add(separator_Titulo_1);
		
		JSeparator separator_Titulo_2 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_2.setForeground(new Color(255, 135, 13));
		separator_Titulo_2.setBackground(new Color(255, 135, 13));
		separator_Titulo_2.setBounds(395, 89, 2, 328);
		contentPane.add(separator_Titulo_2);
		
		JSeparator separator_Titulo_3 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_3.setForeground(new Color(255, 135, 13));
		separator_Titulo_3.setBackground(new Color(255, 135, 13));
		separator_Titulo_3.setBounds(728, 89, 2, 328);
		contentPane.add(separator_Titulo_3);
		
		
		Listado.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent e) {
		
				
                    int selectedRow = Listado.getSelectedRow();
                    btnNueva.setEnabled(true);
                    txtCedula.setEnabled(false);
                    btnEliminar.setEnabled(true); 
                	txtCedula.setText((String) Listado.getValueAt(selectedRow, 0));
                	txtNombre.setText((String) Listado.getValueAt(selectedRow, 1));
                	txtContraseña.setText((String) Listado.getValueAt(selectedRow, 2));
                	comboBox_Usuario.setSelectedItem((String) Listado.getValueAt(selectedRow, 3));
			
               }
        
        });
		
		JLabel lblListado = new JLabel("");
		lblListado.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 1) {
					if (mostrar_tabla==false) {
						
						btnBuscar.setEnabled(false);
	                    btnNueva.setEnabled(true);
	                    txtCedula.setEnabled(false);
	                    btnEliminar.setEnabled(false);
	                    
						setSize(getWidth() + 334, getHeight());
						JOptionPane.showMessageDialog(null,"Agrande la pantalla" );
						panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY(), panel_NegroAbajo.getWidth()+ 329, panel_NegroAbajo.getHeight());
						panel_NegroArriba.setBounds(panel_NegroArriba.getX(), panel_NegroArriba.getY(), panel_NegroArriba.getWidth()+ 329, panel_NegroArriba.getHeight());

						
						String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
						String usuario = "root";
					    String contrasena = "";      
						
						try {
							

							scrollPane_Listado.show();
							mostrar_tabla=true;
							modelo.setRowCount(0);
							
						
							
							Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
							Statement statement = (Statement) conexion.createStatement();
				            String consulta = "SELECT cedula, nombre_usuario, contraseña, tipo_usuario FROM usuario";
				           
				         
				            ResultSet resultSet = statement.executeQuery(consulta);
				        
				          
				            
				            int cant_filas=0;
				            String cedula_1=null;
				            String nombre_usuario_1=null;
				            String contraseña_1=null;
				            String tipo_usuario_1=null;

				            
				            while(resultSet.next()){
				            	JOptionPane.showMessageDialog(null, resultSet.getString("cedula") );			        
				            	
				            	cedula_1=resultSet.getString("cedula");
				            	nombre_usuario_1=resultSet.getString("nombre_usuario");
				            	contraseña_1=resultSet.getString("contraseña");
				            	tipo_usuario_1=resultSet.getString("tipo_usuario");
				            	
				            	modelo.addRow(new Object[] {cedula_1, nombre_usuario_1, contraseña_1, tipo_usuario_1});
				            	
				            	cant_filas++;
				            }
				            
				            resultSet.close();
				            statement.close();
				            conexion.close();
				            
				            
				 
				        } catch (SQLException e1) {
				        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
				}
						
					} else {
				
						mostrar_tabla=false;
						scrollPane_Listado.setVisible(false);	
					    btnBuscar.setEnabled(true);
	                    btnNueva.setEnabled(false);
	                    btnEliminar.setEnabled(false);
	                    txtCedula.setEnabled(true);	
						setSize(getWidth() - 334, getHeight());
						panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY(), panel_NegroAbajo.getWidth()- 329, panel_NegroAbajo.getHeight());
						panel_NegroArriba.setBounds(panel_NegroArriba.getX(), panel_NegroArriba.getY(), panel_NegroArriba.getWidth()- 329, panel_NegroArriba.getHeight());
					
						modelo.setRowCount(0);
						
					}
					
				} 
			}
		});
		lblListado.setHorizontalAlignment(SwingConstants.CENTER);
		lblListado.setIcon(new ImageIcon(Usuario_Modificar.class.getResource("/Presentacion/imagenes/Listado.png")));
		lblListado.setBounds(296, 145, 17, 18);
		contentPane.add(lblListado);
		
		
		
		btnEliminar.setEnabled(false);
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		        String usuario = "root";
		        String contrasena = "";        
		        
				try {
						int opcion=0;
						opcion = JOptionPane.showConfirmDialog(null, "¿Estas seguro que desea eliminar al usuario: " + txtNombre.getText() + "?", "Confirmación eliminar usuario", JOptionPane.YES_NO_OPTION);
						
						if (opcion == JOptionPane.YES_OPTION) {
					
		            					Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
		            					String consulta = "DELETE FROM usuario WHERE cedula = " + Integer.parseInt(txtCedula.getText());
		            					PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
	
		            					int filasEliminadoas = preparedStatement.executeUpdate();
		            					
		            					if (filasEliminadoas > 0) {
		            						JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente.", "Usuario eliminado", JOptionPane.INFORMATION_MESSAGE);
		            						txtCedula.setText("");
		            						txtNombre.setText("");
		            						txtContraseña.setText("");
		            						comboBox_Usuario.setSelectedIndex(0);
		            						btnEliminar.setEnabled(false);
		            						txtCedula.setEnabled(true);
		            						btnNueva.setEnabled(true);
		            						setSize(getWidth() - 334, getHeight());
		            						mostrar_tabla=false;
		            						scrollPane_Listado.setVisible(false);
		            						panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY(), panel_NegroAbajo.getWidth()- 329, panel_NegroAbajo.getHeight());
		            						panel_NegroArriba.setBounds(panel_NegroArriba.getX(), panel_NegroArriba.getY(), panel_NegroArriba.getWidth()- 329, panel_NegroArriba.getHeight());
		            						
		            						
		            						JOptionPane.showMessageDialog(null, " No se pudo eliminar el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
		            					}
		            					modelo.setRowCount(0);

		            					preparedStatement.close();
			    
		            					conexion.close();
						}else {
							txtCedula.setText("");
    						txtNombre.setText("");
    						txtContraseña.setText("");
    						comboBox_Usuario.setSelectedIndex(0);
    						btnEliminar.setEnabled(false);
    						txtCedula.setEnabled(true);
    						btnNueva.setEnabled(true);
						}
		        
		        } catch (SQLException e1) {
		        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

		       }
			}
		});
		btnEliminar.setForeground(Color.WHITE);
		btnEliminar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnEliminar.setBackground(Color.BLACK);
		btnEliminar.setBounds(130, 382, 163, 23);
		contentPane.add(btnEliminar);
		
		btnNueva.setIcon(new ImageIcon(Usuario_Modificar.class.getResource("/Presentacion/imagenes/nueva.png")));
		btnNueva.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtCedula.setEnabled(true);
            	btnBuscar.setEnabled(true);
            	btnNueva.setEnabled(false);
            	btnEliminar.setEnabled(false);
				txtCedula.setText("");
				txtNombre.setText("");
				txtContraseña.setText("");
				comboBox_Usuario.setSelectedIndex(0);				
			}
		});
		btnNueva.setForeground(Color.WHITE);
		btnNueva.setBackground(Color.WHITE);
		btnNueva.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnNueva.setBounds(136, 102, 26, 23);
		contentPane.add(btnNueva);
		
		
	
	}
	}