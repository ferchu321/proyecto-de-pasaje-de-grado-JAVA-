package Presentacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JEditorPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.DropMode;
import javax.swing.JSeparator;
import javax.swing.JProgressBar;
import javax.swing.JTree;
import javax.swing.JFormattedTextField;
import javax.swing.JSpinner;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Proveedor_Registrar extends JFrame {

	private JPanel contentPane;
	private JTextField txtRut;
	private JTextField txtNombre;
	private JTextField txtTelefono;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Proveedor_Registrar frame = new Proveedor_Registrar();
					frame.setVisible(true);
					 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private static boolean esNumerico(String cadena) {
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException e) {          
        	return false;
        }
    }

	/**
	 * Create the frame.
	 */
	public Proveedor_Registrar() {
		setResizable(false);
		setTitle("Registrar proveedor");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Proveedor_Registrar.class.getResource("/Presentacion/imagenes/proveedor.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 608, 435);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtRut = new JTextField();
		txtRut.setBackground(Color.WHITE);
		txtRut.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtRut.setBounds(65, 151, 151, 18);
		txtRut.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtRut);
		txtRut.setColumns(10);
		
		JPanel panelRut = new JPanel();
		panelRut.setBackground(Color.WHITE);
		panelRut.setBounds(59, 138, 163, 37);
		contentPane.add(panelRut);
		TitledBorder Rut = BorderFactory.createTitledBorder("Rut");
		Rut.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Rut.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelRut.setBorder(Rut);
		getContentPane().add(panelRut);
		
		txtNombre = new JTextField();
		txtNombre.setBackground(Color.WHITE);
		txtNombre.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtNombre.setBounds(65, 217, 151, 18);
		txtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		JPanel panelNombre = new JPanel();
		panelNombre.setBackground(Color.WHITE);
		panelNombre.setBounds(59, 204, 163, 37);
		contentPane.add(panelNombre);
		TitledBorder Nombre = BorderFactory.createTitledBorder("Nombre");
		Nombre.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Nombre.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelNombre.setBorder(Nombre);
		getContentPane().add(panelNombre);
		
		txtTelefono = new JTextField();
		txtTelefono.setBackground(Color.WHITE);
		txtTelefono.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtTelefono.setBounds(65, 278, 151, 18);
		txtTelefono.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtTelefono);
		txtTelefono.setColumns(10);
		
		JPanel panelTelefono = new JPanel();
		panelTelefono.setBackground(Color.WHITE);
		panelTelefono.setBounds(59, 265, 163, 37);
		contentPane.add(panelTelefono);
		TitledBorder Telefono = BorderFactory.createTitledBorder("Telefono");
		Telefono.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Telefono.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelTelefono.setBorder(Telefono);
		getContentPane().add(panelTelefono);
		
		JEditorPane editorPane_Descripcion = new JEditorPane();
		editorPane_Descripcion.setBackground(Color.WHITE);
		editorPane_Descripcion.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		editorPane_Descripcion.setBounds(262, 152, 262, 144);
		contentPane.add(editorPane_Descripcion);
		
		JPanel panelDescripcion = new JPanel();
		panelDescripcion.setBackground(Color.WHITE);
		panelDescripcion.setBounds(253, 138, 277, 164);
		contentPane.add(panelDescripcion);
		TitledBorder Descripcion = BorderFactory.createTitledBorder("Descripcion");
		Descripcion.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Descripcion.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelDescripcion.setBorder(Descripcion);
		getContentPane().add(panelDescripcion);
		
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		        String usuario = "root";
		        String contrasena = "";        
		        
				try {
				
				
				if (esNumerico(txtRut.getText())){
					
					if (Integer.parseInt(txtRut.getText())>1000000 && Integer.parseInt(txtRut.getText())<1000000000){
						
						if (txtNombre.getText().length()>0) {
						
							if (esNumerico(txtTelefono.getText())){
							
								if (Integer.parseInt(txtTelefono.getText())>1000000 && Integer.parseInt(txtTelefono.getText())<999999999) {
								
									if (editorPane_Descripcion.getText().length()>0) {
										
										Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
		            					String consulta = "INSERT INTO proveedor VALUES (?, ?, ?, ?)";
		            					PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
	
		            					int rut = Integer.parseInt(txtRut.getText());
		            					String nombre = txtNombre.getText();
		            					int telefono = Integer.parseInt(txtTelefono.getText());
		            					String descripcion = editorPane_Descripcion.getText();
			   
		            					preparedStatement.setInt(1, rut);
		            					preparedStatement.setString(2, nombre);
		            					preparedStatement.setInt(3, telefono);
		            					preparedStatement.setString(4, descripcion);
	
		            					int filasInsertadas = preparedStatement.executeUpdate();
	
		            					if (filasInsertadas > 0) {
		            						JOptionPane.showMessageDialog(null, "Proveedor registrado exitosamente.", "Proveedor creado", JOptionPane.INFORMATION_MESSAGE);
		            						txtRut.setText("");
											txtNombre.setText("");
											txtTelefono.setText("");
											editorPane_Descripcion.setText("");
		            						
		            					} else {
		            						JOptionPane.showMessageDialog(null, " No se pudo insertar el registro.", "Error", JOptionPane.ERROR_MESSAGE);
		            					}
		            					preparedStatement.close();
			    
		            					conexion.close();
										
									}else {
										JOptionPane.showMessageDialog(null, "Error en el descripcion, no puede ser vacia", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
										txtRut.setText("");
										txtNombre.setText("");
										txtTelefono.setText("");
										editorPane_Descripcion.setText("");
									}
									
								}else {
									JOptionPane.showMessageDialog(null, "Error en el telefono, no es valido", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
									txtRut.setText("");
									txtNombre.setText("");
									txtTelefono.setText("");
									editorPane_Descripcion.setText("");
								}
							
							}else {
								JOptionPane.showMessageDialog(null, "Error en el telefono, no es numerico", "Error telefono", JOptionPane.ERROR_MESSAGE);
								txtRut.setText("");
								txtNombre.setText("");
								txtTelefono.setText("");
								editorPane_Descripcion.setText("");
							}
						
						}else {
							JOptionPane.showMessageDialog(null, "Error en el nombre, no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
							txtRut.setText("");
							txtNombre.setText("");
							txtTelefono.setText("");
							editorPane_Descripcion.setText("");
						}
						
					}else {
						JOptionPane.showMessageDialog(null, "Error en el rut, no es valido", "Error", JOptionPane.ERROR_MESSAGE);		        	
						txtRut.setText("");
						txtNombre.setText("");
						txtTelefono.setText("");
						editorPane_Descripcion.setText("");
					}
					
				}else {
					JOptionPane.showMessageDialog(null, "Error en el rut, no es numerico", "Error Rut", JOptionPane.ERROR_MESSAGE);
					txtRut.setText("");
					txtNombre.setText("");
					txtTelefono.setText("");
					editorPane_Descripcion.setText("");
				}
				
				 } catch (SQLException e1) {
			        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			        }
				
			}
		});
		btnIngresar.setForeground(Color.WHITE);
		btnIngresar.setBackground(Color.BLACK);
		btnIngresar.setMnemonic('I');
		btnIngresar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnIngresar.setBounds(367, 307, 163, 23);
		contentPane.add(btnIngresar);
		
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(Proveedor_Registrar.class.getResource("/Presentacion/imagenes/logo.png")));
		lblLogo.setBounds(35, 29, 143, 40);
		contentPane.add(lblLogo);
		
		JLabel lblRegistrarProveedor = new JLabel("Registrar Proveedor");
		lblRegistrarProveedor.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistrarProveedor.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblRegistrarProveedor.setBounds(188, 40, 114, 14);
		contentPane.add(lblRegistrarProveedor);
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 66, 572, 19);
		contentPane.add(panel_NegroArriba);
		
		JSeparator separator_Titulo = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo.setForeground(new Color(255, 135, 13));
		separator_Titulo.setBackground(new Color(255, 135, 13));
		separator_Titulo.setBounds(185, 29, 2, 36);
		contentPane.add(separator_Titulo);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setLayout(null);
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(10, 360, 572, 19);
		contentPane.add(panel_NegroAbajo);
		
		JSeparator separator_Titulo_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1.setBounds(20, 96, 2, 253);
		contentPane.add(separator_Titulo_1);
		
		JSeparator separator_Titulo_1_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBounds(565, 96, 2, 253);
		contentPane.add(separator_Titulo_1_1);
	
	}
}
