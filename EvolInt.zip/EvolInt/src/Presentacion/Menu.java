package Presentacion;



import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.RadialGradientPaint;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenu;
import javax.swing.JMenuBar;


public class Menu extends JFrame {

	private JPanel contentPane;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu("Administrador","");
					frame.setVisible(true);
					  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu(String tipo_menu,String login) {
	
		
		setResizable(false);
		setTitle("Menu");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Menu.class.getResource("/Presentacion/imagenes/icono_app.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 474, 446);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lbluser = new JLabel(login);
		
		lbluser.setHorizontalAlignment(SwingConstants.CENTER);
		lbluser.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lbluser.setForeground(Color.BLACK);
		lbluser.setBounds(348, 11, 86, 14);
		contentPane.add(lbluser);
		

		JPopupMenu popupMenu = new JPopupMenu();

		JMenuItem item_contra = new JMenuItem("Cambiar Contraseña");
		popupMenu.setBorder(new EmptyBorder(0, 0, 0, 0));
		item_contra.setBackground(Color.WHITE);
		item_contra.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		Border border_item_contra = BorderFactory.createLineBorder(new Color(255, 135, 13), 1);
		item_contra.setBorder(border_item_contra);
		
		JSeparator separador = new JSeparator(); 
		separador.setBackground(Color.BLACK);
		
		JMenuItem item_desloguear = new JMenuItem("Desconectarse");
		popupMenu.setBorder(new EmptyBorder(0, 0, 0, 0));
		item_desloguear.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		item_desloguear.setBackground(Color.WHITE);
		item_desloguear.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		Border border_item_desloguear = BorderFactory.createLineBorder(new Color(255, 135, 13), 1);
		item_desloguear.setBorder(border_item_desloguear);

		popupMenu.add(item_contra);
		popupMenu.add(separador);
		popupMenu.add(item_desloguear);
		
		JButton btnRegistrar_Proveedor = new JButton("Registrar");
		btnRegistrar_Proveedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Proveedor_Registrar fromProveedor = new Proveedor_Registrar();
				fromProveedor.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromProveedor.getWidth()) / 2;
		        int y = (screenSize.height - fromProveedor.getHeight()) / 2;
		        fromProveedor.setLocation(x, y);
			}
		});
		btnRegistrar_Proveedor.setBackground(Color.WHITE);
		btnRegistrar_Proveedor.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnRegistrar_Proveedor.setVisible(false);
		Border border_btnRegistrar_Proveedor = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnRegistrar_Proveedor.setBorder(border_btnRegistrar_Proveedor);
		btnRegistrar_Proveedor.setBounds(30, 240, 113, 23);
		contentPane.add(btnRegistrar_Proveedor);
		
		JButton btnEliminar_Proveedor = new JButton("Eliminar");
		btnEliminar_Proveedor.setBackground(Color.WHITE);
		btnEliminar_Proveedor.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnEliminar_Proveedor.setVisible(false);
		Border border_btnEliminar_Proveedor = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnEliminar_Proveedor.setBorder(border_btnEliminar_Proveedor);
		btnEliminar_Proveedor.setBounds(310, 240, 113, 23);
		contentPane.add(btnEliminar_Proveedor);
		
		JButton btnModificar_Proveedor = new JButton("Modificar");
		btnModificar_Proveedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Proveedor_Modificar fromProveedor = new Proveedor_Modificar();
				fromProveedor.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromProveedor.getWidth()) / 2;
		        int y = (screenSize.height - fromProveedor.getHeight()) / 2;
		        fromProveedor.setLocation(x, y);
			}
		});
		btnModificar_Proveedor.setBackground(Color.WHITE);
		btnModificar_Proveedor.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnModificar_Proveedor.setVisible(false);
		Border border_btnModificar_Proveedor = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnModificar_Proveedor.setBorder(border_btnModificar_Proveedor);
		btnModificar_Proveedor.setBounds(170, 240, 113, 23);
		contentPane.add(btnModificar_Proveedor);
		
		JButton btnRegistrar_Compra = new JButton("Registrar");
		btnRegistrar_Compra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Compra_Registrar fromCompra = new Compra_Registrar();
				fromCompra.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromCompra.getWidth()) / 2;
		        int y = (screenSize.height - fromCompra.getHeight()) / 2;
		        fromCompra.setLocation(x, y);
			}
		});
		btnRegistrar_Compra.setBackground(Color.WHITE);
		btnRegistrar_Compra.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnRegistrar_Compra.setVisible(false);
		Border border_btnRegistrar_Compra = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnRegistrar_Compra.setBorder(border_btnRegistrar_Compra);
		btnRegistrar_Compra.setBounds(30, 340, 113, 23);
		contentPane.add(btnRegistrar_Compra);
		
		JButton btnModificar_Compra = new JButton("Modificar");
		btnModificar_Compra.setBackground(Color.WHITE);
		btnModificar_Compra.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnModificar_Compra.setVisible(false);
		Border border_btnModificar_Compra = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnModificar_Compra.setBorder(border_btnModificar_Compra);
		btnModificar_Compra.setBounds(170, 340, 113, 23);
		contentPane.add(btnModificar_Compra);
		
		JButton btnEliminar_Compra = new JButton("Eliminar");
		btnEliminar_Compra.setBackground(Color.WHITE);
		btnEliminar_Compra.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnEliminar_Compra.setVisible(false);
		Border border_btnEliminar_Compra = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnEliminar_Compra.setBorder(border_btnEliminar_Compra);
		btnEliminar_Compra.setBounds(310, 340, 113, 23);
		contentPane.add(btnEliminar_Compra);
		
		JButton btnRegistrar_Producto = new JButton("Registrar");
		btnRegistrar_Producto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Producto_Registrar fromProducto = new Producto_Registrar();
				fromProducto.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromProducto.getWidth()) / 2;
		        int y = (screenSize.height - fromProducto.getHeight()) / 2;
		        fromProducto.setLocation(x, y);
			}
		});
		btnRegistrar_Producto.setBackground(Color.WHITE);
		btnRegistrar_Producto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnRegistrar_Producto.setVisible(false);
		Border border_btnRegistrar_Producto = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnRegistrar_Producto.setBorder(border_btnRegistrar_Producto);
		btnRegistrar_Producto.setBounds(30, 290, 113, 23);
		contentPane.add(btnRegistrar_Producto);
		
		JButton btnModificar_Producto = new JButton("Modificar");
		btnModificar_Producto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Producto_Modificar fromProducto = new Producto_Modificar();
				fromProducto.setVisible(true);
				 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (screenSize.width - fromProducto.getWidth()) / 2;
			        int y = (screenSize.height - fromProducto.getHeight()) / 2;
			        fromProducto.setLocation(x, y);
			        
			}
		});
		btnModificar_Producto.setBackground(Color.WHITE);
		btnModificar_Producto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnModificar_Producto.setVisible(false);
		Border border_btnModificar_Producto = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnModificar_Producto.setBorder(border_btnModificar_Producto);
		btnModificar_Producto.setBounds(170, 290, 113, 23);
		contentPane.add(btnModificar_Producto);
		
		JButton btnEliminar_Producto = new JButton("Eliminar");
		btnEliminar_Producto.setBackground(Color.WHITE);
		btnEliminar_Producto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnEliminar_Producto.setVisible(false);
		Border border_btnEliminar_Producto = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnEliminar_Producto.setBorder(border_btnEliminar_Producto);
		btnEliminar_Producto.setBounds(310, 290, 113, 23);
		contentPane.add(btnEliminar_Producto);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(20, 355, 414, 19);
		contentPane.add(panel_NegroAbajo);
		
		JPanel panel_NegroUsuario = new JPanel();
		panel_NegroUsuario.setBackground(Color.BLACK);
		panel_NegroUsuario.setBounds(20, 130, 414, 10);
		contentPane.add(panel_NegroUsuario);
		
		JPanel panel_NegroCliente = new JPanel();
		panel_NegroCliente.setBackground(Color.BLACK);
		panel_NegroCliente.setBounds(20, 180, 414, 10);
		contentPane.add(panel_NegroCliente);
		
		JPanel panel_NegroProveedor = new JPanel();
		panel_NegroProveedor.setBackground(Color.BLACK);
		panel_NegroProveedor.setBounds(20, 230, 414, 10);
		contentPane.add(panel_NegroProveedor);
		
		JPanel panel_NegroProducto = new JPanel();
		panel_NegroProducto.setBackground(Color.BLACK);
		panel_NegroProducto.setBounds(20, 280, 414, 10);
		contentPane.add(panel_NegroProducto);
		
		//Definición de Botones
		JButton btnCompra = new JButton("Compra");
		JButton btnProducto = new JButton("Producto");
		JButton btnProveedor = new JButton("Proveedor");
		JButton btnCliente = new JButton("Cliente");
		
		JButton btnRegistrar_cliente = new JButton("Registrar ");
		btnRegistrar_cliente.setBackground(Color.WHITE);
		btnRegistrar_cliente.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnRegistrar_cliente.setVisible(false);
		Border border_btnRegistrar_cliente = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnRegistrar_cliente.setBorder(border_btnRegistrar_cliente);
		btnRegistrar_cliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Cliente_Registrar fromCliente = new Cliente_Registrar();
				fromCliente.setVisible(true);
				 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				    int x = (screenSize.width - fromCliente.getWidth()) / 2;
			        int y = (screenSize.height - fromCliente.getHeight()) / 2;
			        fromCliente.setLocation(x, y);
				
			}
		});
		
		JButton btnModificar_cliente = new JButton("Modificar ");
		btnModificar_cliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Cliente_Modificar fromCliente = new Cliente_Modificar();
				fromCliente.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromCliente.getWidth()) / 2;
		        int y = (screenSize.height - fromCliente.getHeight()) / 2;
		        fromCliente.setLocation(x, y);
			}
		});
		btnModificar_cliente.setBackground(Color.WHITE);
		btnModificar_cliente.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnModificar_cliente.setVisible(false);
		Border border_btnModificar_cliente = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnModificar_cliente.setBorder(border_btnModificar_cliente);
		btnModificar_cliente.setBounds(170, 190, 113, 23);
		contentPane.add(btnModificar_cliente);
		
		JButton btnEliminar_cliente = new JButton("Eliminar ");
		btnEliminar_cliente.setBackground(Color.WHITE);
		btnEliminar_cliente.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnEliminar_cliente.setVisible(false);
		Border border_btnEliminar_cliente = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnEliminar_cliente.setBorder(border_btnEliminar_cliente);
		btnEliminar_cliente.setBounds(310, 190, 113, 23);
		contentPane.add(btnEliminar_cliente);
		
		JPanel panel_NegroCompra = new JPanel();
		panel_NegroCompra.setBackground(Color.BLACK);
		panel_NegroCompra.setBounds(20, 330, 414, 10);
		contentPane.add(panel_NegroCompra);
		btnRegistrar_cliente.setBounds(30, 190, 113, 23);
		contentPane.add(btnRegistrar_cliente);
		
		JButton btnRegistrar_Usuario = new JButton("Registrar");
		btnRegistrar_Usuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Usuario_Registrar fromUsuario = new Usuario_Registrar();
				fromUsuario.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromUsuario.getWidth()) / 2;
		        int y = (screenSize.height - fromUsuario.getHeight()) / 2;
		        fromUsuario.setLocation(x, y);
			}
		});
		btnRegistrar_Usuario.setBackground(Color.WHITE);
		btnRegistrar_Usuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnRegistrar_Usuario.setVisible(false);
		Border border_btnRegistrar_Usuario = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnRegistrar_Usuario.setBorder(border_btnRegistrar_Usuario);
		btnRegistrar_Usuario.setBounds(30, 140, 113, 23);
		contentPane.add(btnRegistrar_Usuario);
		
		JButton btnModificar_Usuario = new JButton("Modificar");
		btnModificar_Usuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Usuario_Modificar fromUsuario = new Usuario_Modificar();
				fromUsuario.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromUsuario.getWidth()) / 2;
		        int y = (screenSize.height - fromUsuario.getHeight()) / 2;
		        fromUsuario.setLocation(x, y);
			}
		});
		btnModificar_Usuario.setBackground(Color.WHITE);
		btnModificar_Usuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnModificar_Usuario.setVisible(false);
		Border border_btnModificar_Usuario = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnModificar_Usuario.setBorder(border_btnModificar_Usuario);
		btnModificar_Usuario.setBounds(170, 140, 113, 23);
		contentPane.add(btnModificar_Usuario);
		
		JButton btnEliminar_Usuario = new JButton("Eliminar");
		btnEliminar_Usuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Usuario_Eliminar fromUsuario = new Usuario_Eliminar();
				fromUsuario.setVisible(true);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (screenSize.width - fromUsuario.getWidth()) / 2;
		        int y = (screenSize.height - fromUsuario.getHeight()) / 2;
		        fromUsuario.setLocation(x, y);
			}
		});
		btnEliminar_Usuario.setBackground(Color.WHITE);
		btnEliminar_Usuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 10));
		btnEliminar_Usuario.setVisible(false);
		Border border_btnEliminar_Usuario = BorderFactory.createLineBorder(new Color(255, 135, 13), 2);
		btnEliminar_Usuario.setBorder(border_btnEliminar_Usuario);
		btnEliminar_Usuario.setBounds(310, 140, 113, 23);
		contentPane.add(btnEliminar_Usuario);
		
		//Si al llamar al menu el valor de Parametro es Administrador
		if (tipo_menu=="Administrador") {
			JButton btnUsuario = new JButton("Usuario");
			btnUsuario.setIcon(new ImageIcon(Menu.class.getResource("/Presentacion/imagenes/usuario.png")));
			btnUsuario.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				
					if (btnRegistrar_Usuario.isVisible()==true) {
						setResizable(true);
						setSize(getWidth(), getHeight() - 25);
						btnRegistrar_Usuario.setVisible(false);
						btnModificar_Usuario.setVisible(false);
						btnEliminar_Usuario.setVisible(false);	
						
						
						//Reescribir todos los controles
						
						btnCliente.setBounds(btnCliente.getX(), btnCliente.getY() - 25,btnCliente.getWidth(), btnCliente.getHeight());
						panel_NegroCliente.setBounds(panel_NegroCliente.getX(), panel_NegroCliente.getY() - 25, panel_NegroCliente.getWidth(), panel_NegroCliente.getHeight());
						
						btnRegistrar_cliente.setBounds(btnRegistrar_cliente.getX(),btnCliente.getY() + 45,btnRegistrar_cliente.getWidth(),btnRegistrar_cliente.getHeight());
						btnModificar_cliente.setBounds(btnModificar_cliente.getX(),btnCliente.getY() + 45,btnModificar_cliente.getWidth(),btnModificar_cliente.getHeight());
						btnEliminar_cliente.setBounds(btnEliminar_cliente.getX(),btnCliente.getY() + 45,btnEliminar_cliente.getWidth(),btnEliminar_cliente.getHeight());
						
						btnProveedor.setBounds(btnProveedor.getX(), btnProveedor.getY() - 25,btnProveedor.getWidth(), btnProveedor.getHeight());
						panel_NegroProveedor.setBounds(panel_NegroProveedor.getX(), panel_NegroProveedor.getY() - 25, panel_NegroProveedor.getWidth(), panel_NegroProveedor.getHeight());
						
						btnRegistrar_Proveedor.setBounds(btnRegistrar_Proveedor.getX(),btnProveedor.getY() + 45,btnRegistrar_Proveedor.getWidth(),btnRegistrar_Proveedor.getHeight());
						btnModificar_Proveedor.setBounds(btnModificar_Proveedor.getX(),btnProveedor.getY() + 45,btnModificar_Proveedor.getWidth(),btnModificar_Proveedor.getHeight());
						btnEliminar_Proveedor.setBounds(btnEliminar_Proveedor.getX(),btnProveedor.getY() + 45,btnEliminar_Proveedor.getWidth(),btnEliminar_Proveedor.getHeight());
						
						btnProducto.setBounds(btnProducto.getX(), btnProducto.getY() - 25,btnProducto.getWidth(), btnProducto.getHeight());
						panel_NegroProducto.setBounds(panel_NegroProducto.getX(), panel_NegroProducto.getY() - 25, panel_NegroProducto.getWidth(), panel_NegroProducto.getHeight());
						
						btnRegistrar_Producto.setBounds(btnRegistrar_Producto.getX(),btnProducto.getY()+45,btnRegistrar_Producto.getWidth(),btnRegistrar_Producto.getHeight());
						btnModificar_Producto.setBounds(btnModificar_Producto.getX(),btnProducto.getY()+45,btnModificar_Producto.getWidth(),btnModificar_Producto.getHeight());
						btnEliminar_Producto.setBounds(btnEliminar_Producto.getX(),btnProducto.getY()+45,btnEliminar_Producto.getWidth(),btnEliminar_Producto.getHeight());
						
						btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() - 25,btnCompra.getWidth(), btnCompra.getHeight());
						panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() - 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
						
						btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
						btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
						btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
						
						panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() - 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
						

					
						setResizable(false);
					} else {
						
						setResizable(true);
						setSize(getWidth(), getHeight() + 25);
						
						//Reescribir todos los controles
						
						btnCliente.setBounds(btnCliente.getX(), btnCliente.getY() + 25,btnCliente.getWidth(), btnCliente.getHeight());
						panel_NegroCliente.setBounds(panel_NegroCliente.getX(), panel_NegroCliente.getY() + 25, panel_NegroCliente.getWidth(), panel_NegroCliente.getHeight());
						
						btnRegistrar_cliente.setBounds(btnRegistrar_cliente.getX(),btnCliente.getY() + 45,btnRegistrar_cliente.getWidth(),btnRegistrar_cliente.getHeight());
						btnModificar_cliente.setBounds(btnModificar_cliente.getX(),btnCliente.getY() + 45,btnModificar_cliente.getWidth(),btnModificar_cliente.getHeight());
						btnEliminar_cliente.setBounds(btnEliminar_cliente.getX(),btnCliente.getY() + 45,btnEliminar_cliente.getWidth(),btnEliminar_cliente.getHeight());
						
						btnProveedor.setBounds(btnProveedor.getX(), btnProveedor.getY() + 25, btnProveedor.getWidth(), btnProveedor.getHeight());
						panel_NegroProveedor.setBounds(panel_NegroProveedor.getX(), panel_NegroProveedor.getY() + 25, panel_NegroProveedor.getWidth(), panel_NegroProveedor.getHeight());

						btnRegistrar_Proveedor.setBounds(btnRegistrar_Proveedor.getX(),btnProveedor.getY() + 45,btnRegistrar_Proveedor.getWidth(),btnRegistrar_Proveedor.getHeight());
						btnModificar_Proveedor.setBounds(btnModificar_Proveedor.getX(),btnProveedor.getY() + 45,btnModificar_Proveedor.getWidth(),btnModificar_Proveedor.getHeight());
						btnEliminar_Proveedor.setBounds(btnEliminar_Proveedor.getX(),btnProveedor.getY() + 45,btnEliminar_Proveedor.getWidth(),btnEliminar_Proveedor.getHeight());
						
						btnProducto.setBounds(btnProducto.getX(), btnProducto.getY() + 25,btnProducto.getWidth(), btnProducto.getHeight());
						panel_NegroProducto.setBounds(panel_NegroProducto.getX(), panel_NegroProducto.getY() + 25, panel_NegroProducto.getWidth(), panel_NegroProducto.getHeight());
						
						btnRegistrar_Producto.setBounds(btnRegistrar_Producto.getX(),btnProducto.getY()+45,btnRegistrar_Producto.getWidth(),btnRegistrar_Producto.getHeight());
						btnModificar_Producto.setBounds(btnModificar_Producto.getX(),btnProducto.getY()+45,btnModificar_Producto.getWidth(),btnModificar_Producto.getHeight());
						btnEliminar_Producto.setBounds(btnEliminar_Producto.getX(),btnProducto.getY()+45,btnEliminar_Producto.getWidth(),btnEliminar_Producto.getHeight());
						
						btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() + 25,btnCompra.getWidth(), btnCompra.getHeight());
						panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() + 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
						
						btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
						btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
						btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
						
						panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() + 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
							
						btnRegistrar_Usuario.setVisible(true);
						btnModificar_Usuario.setVisible(true);
						btnEliminar_Usuario.setVisible(true);
						setResizable(false);
					}
						
					
				}
			});
			btnUsuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
			btnUsuario.setBounds(20, 145, 414, 35);
			contentPane.add(btnUsuario);
			
			
			
			btnUsuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
			btnUsuario.setBackground(Color.WHITE);
			btnUsuario.setForeground(Color.BLACK);
			btnUsuario.setBounds(20, 95, 414, 35);
			contentPane.add(btnUsuario);
			
		}
		
		
		btnCliente.setBackground(Color.WHITE);
		btnCliente.setIcon(new ImageIcon(Menu.class.getResource("/Presentacion/imagenes/cliente.png")));
		btnCliente.addActionListener(new ActionListener() {	
			public void actionPerformed(ActionEvent e) {
			
				
				//Si los botones estan visibles, los oculto
				if (btnRegistrar_cliente.isVisible()==true) {
					setResizable(true);
					setSize(getWidth(), getHeight() - 25);
					btnRegistrar_cliente.setVisible(false);
					btnModificar_cliente.setVisible(false);
					btnEliminar_cliente.setVisible(false);	
					
					
					//Reescribir todos los controles
					
					btnProveedor.setBounds(btnProveedor.getX(), btnProveedor.getY() - 25,btnProveedor.getWidth(), btnProveedor.getHeight());
					panel_NegroProveedor.setBounds(panel_NegroProveedor.getX(), panel_NegroProveedor.getY() - 25, panel_NegroProveedor.getWidth(), panel_NegroProveedor.getHeight());
					
					btnRegistrar_Proveedor.setBounds(btnRegistrar_Proveedor.getX(),btnProveedor.getY() + 45,btnRegistrar_Proveedor.getWidth(),btnRegistrar_Proveedor.getHeight());
					btnModificar_Proveedor.setBounds(btnModificar_Proveedor.getX(),btnProveedor.getY() + 45,btnModificar_Proveedor.getWidth(),btnModificar_Proveedor.getHeight());
					btnEliminar_Proveedor.setBounds(btnEliminar_Proveedor.getX(),btnProveedor.getY() + 45,btnEliminar_Proveedor.getWidth(),btnEliminar_Proveedor.getHeight());
					
					btnProducto.setBounds(btnProducto.getX(), btnProducto.getY() - 25,btnProducto.getWidth(), btnProducto.getHeight());
					panel_NegroProducto.setBounds(panel_NegroProducto.getX(), panel_NegroProducto.getY() - 25, panel_NegroProducto.getWidth(), panel_NegroProducto.getHeight());
					
					btnRegistrar_Producto.setBounds(btnRegistrar_Producto.getX(),btnProducto.getY()+45,btnRegistrar_Producto.getWidth(),btnRegistrar_Producto.getHeight());
					btnModificar_Producto.setBounds(btnModificar_Producto.getX(),btnProducto.getY()+45,btnModificar_Producto.getWidth(),btnModificar_Producto.getHeight());
					btnEliminar_Producto.setBounds(btnEliminar_Producto.getX(),btnProducto.getY()+45,btnEliminar_Producto.getWidth(),btnEliminar_Producto.getHeight());
					
					btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() - 25,btnCompra.getWidth(), btnCompra.getHeight());
					panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() - 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
					
					btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
					btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
					btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
					
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() - 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
					

				
					setResizable(false);
				} else {
					
					setResizable(true);
					setSize(getWidth(), getHeight() + 25);
					
					//Reescribir todos los controles
					btnProveedor.setBounds(btnProveedor.getX(), btnProveedor.getY() + 25, btnProveedor.getWidth(), btnProveedor.getHeight());
					panel_NegroProveedor.setBounds(panel_NegroProveedor.getX(), panel_NegroProveedor.getY() + 25, panel_NegroProveedor.getWidth(), panel_NegroProveedor.getHeight());

					btnRegistrar_Proveedor.setBounds(btnRegistrar_Proveedor.getX(),btnProveedor.getY() + 45,btnRegistrar_Proveedor.getWidth(),btnRegistrar_Proveedor.getHeight());
					btnModificar_Proveedor.setBounds(btnModificar_Proveedor.getX(),btnProveedor.getY() + 45,btnModificar_Proveedor.getWidth(),btnModificar_Proveedor.getHeight());
					btnEliminar_Proveedor.setBounds(btnEliminar_Proveedor.getX(),btnProveedor.getY() + 45,btnEliminar_Proveedor.getWidth(),btnEliminar_Proveedor.getHeight());
					
					btnProducto.setBounds(btnProducto.getX(), btnProducto.getY() + 25,btnProducto.getWidth(), btnProducto.getHeight());
					panel_NegroProducto.setBounds(panel_NegroProducto.getX(), panel_NegroProducto.getY() + 25, panel_NegroProducto.getWidth(), panel_NegroProducto.getHeight());
					
					btnRegistrar_Producto.setBounds(btnRegistrar_Producto.getX(),btnProducto.getY()+45,btnRegistrar_Producto.getWidth(),btnRegistrar_Producto.getHeight());
					btnModificar_Producto.setBounds(btnModificar_Producto.getX(),btnProducto.getY()+45,btnModificar_Producto.getWidth(),btnModificar_Producto.getHeight());
					btnEliminar_Producto.setBounds(btnEliminar_Producto.getX(),btnProducto.getY()+45,btnEliminar_Producto.getWidth(),btnEliminar_Producto.getHeight());
					
					btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() + 25,btnCompra.getWidth(), btnCompra.getHeight());
					panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() + 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
					
					btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
					btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
					btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
					
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() + 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
						
					btnRegistrar_cliente.setVisible(true);
					btnModificar_cliente.setVisible(true);
					btnEliminar_cliente.setVisible(true);
					setResizable(false);
				}
					
				
			}
		});
		btnCliente.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnCliente.setBounds(20, 145, 414, 35);
		contentPane.add(btnCliente);
		
		
	        
		//Definición Compra
		btnCompra.setIcon(new ImageIcon(Menu.class.getResource("/Presentacion/imagenes/Compra.png")));
		btnCompra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (btnRegistrar_Compra.isVisible()==true) {
					setResizable(true);
					setSize(getWidth(), getHeight() - 25);
					btnRegistrar_Compra.setVisible(false);
					btnModificar_Compra.setVisible(false);
					btnEliminar_Compra.setVisible(false);
					
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() - 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
				
					setResizable(false);
				} else {
					
					setResizable(true);
					setSize(getWidth(), getHeight() + 25);
						
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() + 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
								
					btnRegistrar_Compra.setVisible(true);
					btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
					btnModificar_Compra.setVisible(true);
					btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
					btnEliminar_Compra.setVisible(true);
					btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
					setResizable(false);
				}
				
				
				
			}
		});
		btnCompra.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnCompra.setBackground(Color.WHITE);
		btnCompra.setBounds(20, 295, 414, 35);
		contentPane.add(btnCompra);
		
		
		//Definición Boton Producto
		btnProducto.setIcon(new ImageIcon(Menu.class.getResource("/Presentacion/imagenes/producto.png")));
		btnProducto.setBackground(Color.WHITE);
		btnProducto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (btnRegistrar_Producto.isVisible()==true) {
					setResizable(true);
					setSize(getWidth(), getHeight() - 25);
					btnRegistrar_Producto.setVisible(false);
					btnModificar_Producto.setVisible(false);
					btnEliminar_Producto.setVisible(false);
			
					
					//Reescribir todos los controles
					
					btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() - 25,btnCompra.getWidth(), btnCompra.getHeight());
					panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() - 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
					
					btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
					btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
					btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
					
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() - 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
				
					setResizable(false);
				} else {
					
					setResizable(true);
					setSize(getWidth(), getHeight() + 25);
					
					//Reescribir todos los controles
					
					btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() + 25,btnCompra.getWidth(), btnCompra.getHeight());
					panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() + 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
					
					btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
					btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
					btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
					
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() + 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
									
					btnRegistrar_Producto.setVisible(true);
					btnRegistrar_Producto.setBounds(btnRegistrar_Producto.getX(),btnProducto.getY()+45,btnRegistrar_Producto.getWidth(),btnRegistrar_Producto.getHeight());
					btnModificar_Producto.setVisible(true);
					btnModificar_Producto.setBounds(btnModificar_Producto.getX(),btnProducto.getY()+45,btnModificar_Producto.getWidth(),btnModificar_Producto.getHeight());
					btnEliminar_Producto.setVisible(true);
					btnEliminar_Producto.setBounds(btnEliminar_Producto.getX(),btnProducto.getY()+45,btnEliminar_Producto.getWidth(),btnEliminar_Producto.getHeight());
					setResizable(false);
				}
				
				
				
				
			}
		});
		btnProducto.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnProducto.setBounds(20, 245, 414, 35);
		contentPane.add(btnProducto);
		
		//Definicion boton proveedor
		btnProveedor.setIcon(new ImageIcon(Menu.class.getResource("/Presentacion/imagenes/proveedor.png")));
		btnProveedor.setBackground(Color.WHITE);
		btnProveedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//Si los botones estan visibles, los oculto
				if (btnRegistrar_Proveedor.isVisible()==true) {
					setResizable(true);
					setSize(getWidth(), getHeight() - 25);
					btnRegistrar_Proveedor.setVisible(false);
					btnModificar_Proveedor.setVisible(false);
					btnEliminar_Proveedor.setVisible(false);
			
					//Reescribir todos los controles
					btnProducto.setBounds(btnProducto.getX(), btnProducto.getY() - 25,btnProducto.getWidth(), btnProducto.getHeight());
					panel_NegroProducto.setBounds(panel_NegroProducto.getX(), panel_NegroProducto.getY() - 25, panel_NegroProducto.getWidth(), panel_NegroProducto.getHeight());
					
					btnRegistrar_Producto.setBounds(btnRegistrar_Producto.getX(),btnProducto.getY()+45,btnRegistrar_Producto.getWidth(),btnRegistrar_Producto.getHeight());
					btnModificar_Producto.setBounds(btnModificar_Producto.getX(),btnProducto.getY()+45,btnModificar_Producto.getWidth(),btnModificar_Producto.getHeight());
					btnEliminar_Producto.setBounds(btnEliminar_Producto.getX(),btnProducto.getY()+45,btnEliminar_Producto.getWidth(),btnEliminar_Producto.getHeight());
					
					btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() - 25,btnCompra.getWidth(), btnCompra.getHeight());
					panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() - 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
					
					btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
					btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
					btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
					
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() - 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
				
					
					
					setResizable(false);
				} else {
					
					setResizable(true);
					setSize(getWidth(), getHeight() + 25);
					
					//Reescribir todos los controles
					btnProducto.setBounds(btnProducto.getX(), btnProducto.getY() + 25,btnProducto.getWidth(), btnProducto.getHeight());
					panel_NegroProducto.setBounds(panel_NegroProducto.getX(), panel_NegroProducto.getY() + 25, panel_NegroProducto.getWidth(), panel_NegroProducto.getHeight());
					
					btnRegistrar_Producto.setBounds(btnRegistrar_Producto.getX(),btnProducto.getY()+45,btnRegistrar_Producto.getWidth(),btnRegistrar_Producto.getHeight());
					btnModificar_Producto.setBounds(btnModificar_Producto.getX(),btnProducto.getY()+45,btnModificar_Producto.getWidth(),btnModificar_Producto.getHeight());
					btnEliminar_Producto.setBounds(btnEliminar_Producto.getX(),btnProducto.getY()+45,btnEliminar_Producto.getWidth(),btnEliminar_Producto.getHeight());
					
					btnCompra.setBounds(btnCompra.getX(), btnCompra.getY() + 25,btnCompra.getWidth(), btnCompra.getHeight());
					panel_NegroCompra.setBounds(panel_NegroCompra.getX(), panel_NegroCompra.getY() + 25, panel_NegroCompra.getWidth(), panel_NegroCompra.getHeight());
					
					btnRegistrar_Compra.setBounds(btnRegistrar_Compra.getX(),btnCompra.getY()+45,btnRegistrar_Compra.getWidth(),btnRegistrar_Compra.getHeight());
					btnModificar_Compra.setBounds(btnModificar_Compra.getX(),btnCompra.getY()+45,btnModificar_Compra.getWidth(),btnModificar_Compra.getHeight());
					btnEliminar_Compra.setBounds(btnEliminar_Compra.getX(),btnCompra.getY()+45,btnEliminar_Compra.getWidth(),btnEliminar_Compra.getHeight());
					
					panel_NegroAbajo.setBounds(panel_NegroAbajo.getX(), panel_NegroAbajo.getY() + 25, panel_NegroAbajo.getWidth(), panel_NegroAbajo.getHeight());
									
					btnRegistrar_Proveedor.setVisible(true);
					btnRegistrar_Proveedor.setBounds(btnRegistrar_Proveedor.getX(),btnProveedor.getY()+45,btnRegistrar_Proveedor.getWidth(),btnRegistrar_Proveedor.getHeight());
					btnModificar_Proveedor.setVisible(true);
					btnModificar_Proveedor.setBounds(btnModificar_Proveedor.getX(),btnProveedor.getY()+45,btnModificar_Proveedor.getWidth(),btnModificar_Proveedor.getHeight());
					btnEliminar_Proveedor.setVisible(true);
					btnEliminar_Proveedor.setBounds(btnEliminar_Proveedor.getX(),btnProveedor.getY()+45,btnEliminar_Proveedor.getWidth(),btnEliminar_Proveedor.getHeight());
					
					setResizable(false);
				}
				
				
				
				
			
			}
		});
		btnProveedor.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnProveedor.setBounds(20, 195, 414, 35);
		contentPane.add(btnProveedor);
		
		//Definición Imagenes
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(Menu.class.getResource("/Presentacion/imagenes/logo.png")));
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(30, 26, 160, 43);
		contentPane.add(lblLogo);
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(20, 65, 414, 19);
		contentPane.add(panel_NegroArriba);
		panel_NegroArriba.setLayout(null);
		
		JLabel lblUser = new JLabel("");
		lblUser.addMouseListener(new MouseAdapter() {
			 boolean opcion_menu=false;
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 1) {
					if (opcion_menu==false) {
						popupMenu.show(e.getComponent(), -50, 32);
						opcion_menu=true;
					} else {
						opcion_menu=false;
						popupMenu.setVisible(false);
						
					}
					
				} 
			}
		});
		
		//Item Desloguearme
		item_desloguear.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	Login win= new Login();
	        		win.main(null);
	        		dispose();
	            }
	        });
		
		//Item Cambiar contraseña
		item_contra.addActionListener(new ActionListener() {
			    @Override
			    public void actionPerformed(ActionEvent e) {
			    	Cambiar_Contraseña frame = new Cambiar_Contraseña(login);
			    	frame.setVisible(true);
			    	 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
	        		
			    }
			});
		 
		lblUser.setIcon(new ImageIcon(Menu.class.getResource("/Presentacion/imagenes/usuario.png")));
		lblUser.setBounds(377, 29, 30, 30);
		contentPane.add(lblUser);
	
	}

}
