package Presentacion;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Cambiar_Contraseña extends JFrame {

	private JPanel contentPane;
	private JPasswordField txtContraseñaActual;
	private JPasswordField txtContraseñaNueva;
	private JPasswordField txtConfirmarContraseña;
	private JPanel panel_NuevaContraseña;
	private JPanel panel_ConfirmarContraseña;
	private JPanel panel_NegroArriba;
	private JSeparator separator_Titulo;
	private JLabel lblCambiarContraseña;
	private JSeparator separator_Titulo_1;
	private JSeparator separator_Titulo_2;
	private JLabel lblVisibleNueva;
	private JTextField txtContraseñaNuevaVisible;
	private JTextField txtContraseñaActualVisible;
	private JLabel lblVisibleConfirmar;
	private JTextField txtConfirmarContraseñaVisible;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cambiar_Contraseña frame = new Cambiar_Contraseña(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private void cambiocontraseña(String login) {
		
		String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
		String usuario = "root";
	    String contrasena = "";        
	        
	    try {
			
	    		if(txtContraseñaActual.getText().length()>=8) {
	       			if(txtContraseñaNueva.getText().length()>=8) {			
	    					if (txtContraseñaActual.getText().equals(txtContraseñaNueva.getText())) {
	    						JOptionPane.showMessageDialog(null, "Error la contraseña nueva no puede ser igual a la contraseña actual", "Error", JOptionPane.INFORMATION_MESSAGE);	
	    					}else {
	    							if (!txtContraseñaNueva.getText().equals(txtConfirmarContraseña.getText())) {
	    								JOptionPane.showMessageDialog(null, "Error las contraseñas no coinciden", "Error", JOptionPane.INFORMATION_MESSAGE);
	    							}else {
	    								//Hago lo que tengo que hacer
	    								
		    								Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
		    								Statement statement = (Statement) conexion.createStatement();
		    								String consulta = "SELECT AES_DECRYPT(contraseña, 'EvolInt_Proyecto') AS contraseña FROM usuario WHERE nombre_usuario = '" + login + "'" ;
			            					
		    								PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
		    								ResultSet resultSet = statement.executeQuery(consulta);
		    								int cant_filas=0;
		    								 String contra=null;
		    								 while (resultSet.next()) {
		    									  contra= resultSet.getString("contraseña");
		    						            	cant_filas++;
		    						            	}
		    								
		    								preparedStatement.close();
		    								if(!txtContraseñaActual.getText().equals(contra)) {
			    								JOptionPane.showMessageDialog(null, "Error su contraseña no es correcta", "Error", JOptionPane.INFORMATION_MESSAGE);

		    								}else {
   								
		    									String consulta1 = "UPDATE usuario SET contraseña= AES_ENCRYPT(?, 'EvolInt_Proyecto') WHERE nombre_usuario= '" + login + "'";
		    									PreparedStatement preparedStatement1 = conexion.prepareStatement(consulta1);
		
		    									String contraseña = txtContraseñaNueva.getText();
			            					
		    									preparedStatement1.setString(1, contraseña);
			            					
		
		    									int filasModificadas = preparedStatement1.executeUpdate();
		
				            					if (filasModificadas > 0) {
				            						JOptionPane.showMessageDialog(null, "Contraseña Modificada exitosamente.", "Contraseña modificada", JOptionPane.INFORMATION_MESSAGE);
				            						txtContraseñaActual.setText("");
				            						txtContraseñaNueva.setText("");
				            						txtConfirmarContraseña.setText("");
				            						
				            					} else {
				            						JOptionPane.showMessageDialog(null, "No se pudo modificar la contraseña.", "Error", JOptionPane.ERROR_MESSAGE);
				            					}
				            					preparedStatement1.close();
					    
				            					conexion.close();
	    								}					
	    							}	
	    					}
	       			}
	    				else {
		    				JOptionPane.showMessageDialog(null, "Error la contraseña debe contener 8 caracteres como minimo", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
	    				}
	    				}
	    				
	    			else {
	    				JOptionPane.showMessageDialog(null, "Error la contraseña debe contener 8 caracteres como minimo", "Error", JOptionPane.INFORMATION_MESSAGE);		        	

	    			}
	    		
	    	
		
	    		} catch (SQLException e1) {
	    	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    				
    				
    	}
	   
	}
	/**
	 * Create the frame.
	 */
	public Cambiar_Contraseña(String login) {
		setTitle("Cambiar contraseña");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Cambiar_Contraseña.class.getResource("/Presentacion/imagenes/icono_app.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 454, 476);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblVisibleNueva = new JLabel("");
		lblVisibleNueva.setIcon(new ImageIcon(Cambiar_Contraseña.class.getResource("/Presentacion/imagenes/mostrar contraseña.png")));
		lblVisibleNueva.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getButton()== 1) {
				
				txtContraseñaNuevaVisible.setVisible(true);
				txtContraseñaNuevaVisible.setText(txtContraseñaNueva.getText());
				txtContraseñaNueva.setVisible(false);
				txtContraseñaNuevaVisible.requestFocus();
				}
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				//txtContraseñaNuevaVisible.setText(txtContraseñaNueva.getText());
				txtContraseñaNuevaVisible.setVisible(false);
				txtContraseñaNueva.setVisible(true);
				txtContraseñaNueva.requestFocus();
			}
		});
		
		JLabel lblVisibleActual = new JLabel("");
		lblVisibleActual.setIcon(new ImageIcon(Cambiar_Contraseña.class.getResource("/Presentacion/imagenes/mostrar contraseña.png")));
		lblVisibleActual.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getButton()== 1) {
				
				txtContraseñaActualVisible.setVisible(true);
				txtContraseñaActualVisible.setText(txtContraseñaActual.getText());
				txtContraseñaActual.setVisible(false);
				txtContraseñaActualVisible.requestFocus();
				}
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				txtContraseñaActualVisible.setVisible(false);
				txtContraseñaActual.setVisible(true);
				txtContraseñaActual.requestFocus();
			}
		});
		
		lblVisibleConfirmar = new JLabel("");
		lblVisibleConfirmar.setIcon(new ImageIcon(Cambiar_Contraseña.class.getResource("/Presentacion/imagenes/mostrar contraseña.png")));
		lblVisibleConfirmar.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getButton()== 1) {
				
					txtConfirmarContraseñaVisible.setVisible(true);
					txtConfirmarContraseñaVisible.setText(txtConfirmarContraseña.getText());
					lblVisibleConfirmar.setVisible(false);
					txtConfirmarContraseñaVisible.requestFocus();
				}
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				txtConfirmarContraseñaVisible.setVisible(false);
				lblVisibleConfirmar.setVisible(true);
				txtConfirmarContraseña.requestFocus();
			}
		});
		lblVisibleConfirmar.setBounds(299, 271, 20, 23);
		contentPane.add(lblVisibleConfirmar);
		lblVisibleActual.setBounds(299, 122, 20, 23);
		contentPane.add(lblVisibleActual);
		
		lblVisibleNueva.setBounds(299, 194, 20, 23);
		contentPane.add(lblVisibleNueva);
		
		txtContraseñaNueva = new JPasswordField();
		txtContraseñaNueva.setBounds(144, 199, 151, 18);
		txtContraseñaNueva.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtContraseñaNueva);
		
		txtConfirmarContraseña = new JPasswordField();
		txtConfirmarContraseña.setBounds(144, 276, 151, 18);
		txtConfirmarContraseña.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtConfirmarContraseña);
		
		txtContraseñaActual = new JPasswordField();
		txtContraseñaActual.setBackground(Color.WHITE);
		txtContraseñaActual.setBounds(144, 125, 151, 18);
		txtContraseñaActual.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtContraseñaActual);
		
		JPanel panel_ContraseñaActual = new JPanel();
		panel_ContraseñaActual.setBackground(Color.WHITE);
		panel_ContraseñaActual.setBounds(138, 112, 163, 37);
		
		//Declaro estilo de bordes de Titulos
		TitledBorder ContraseñaActual = BorderFactory.createTitledBorder("Contraseña actual");
		ContraseñaActual.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		ContraseñaActual.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panel_ContraseñaActual.setBorder(ContraseñaActual);
		contentPane.add(panel_ContraseñaActual);
		
		
		panel_NuevaContraseña = new JPanel();
		panel_NuevaContraseña.setBackground(Color.WHITE);
		panel_NuevaContraseña.setBounds(138, 186, 163, 37);
		TitledBorder NuevaContraseña = BorderFactory.createTitledBorder("Nueva contraseña");
		NuevaContraseña.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		NuevaContraseña.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título

		panel_NuevaContraseña.setBorder(NuevaContraseña);
		contentPane.add(panel_NuevaContraseña);
		
		panel_ConfirmarContraseña = new JPanel();
		panel_ConfirmarContraseña.setBackground(Color.WHITE);
		panel_ConfirmarContraseña.setBounds(138, 263, 163, 37);
		
		TitledBorder ConfirmarContraseña = BorderFactory.createTitledBorder("Confirmar contraseña");
		ConfirmarContraseña.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		ConfirmarContraseña.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panel_ConfirmarContraseña.setBorder(ConfirmarContraseña);
		contentPane.add(panel_ConfirmarContraseña);
		
		panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 61, 418, 19);
		contentPane.add(panel_NegroArriba);
		
		
		txtContraseñaNuevaVisible = new JTextField();
		txtContraseñaNuevaVisible.setVisible(false);
		txtContraseñaNuevaVisible.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtContraseñaNuevaVisible.setBounds(144, 199, 151, 18);
		contentPane.add(txtContraseñaNuevaVisible);
		txtContraseñaNuevaVisible.setColumns(10);
		
		JButton btnCambiarContraseña = new JButton("Cambiar contraseña");
		btnCambiarContraseña.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cambiocontraseña(login);
				
				
			}
		});
		btnCambiarContraseña.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnCambiarContraseña.setBackground(Color.BLACK);
		btnCambiarContraseña.setForeground(Color.WHITE);
		btnCambiarContraseña.setBounds(138, 325, 157, 23);
		contentPane.add(btnCambiarContraseña);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setLayout(null);
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(10, 392, 418, 19);
		contentPane.add(panel_NegroAbajo);
		
		separator_Titulo = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo.setForeground(new Color(255, 135, 13));
		separator_Titulo.setBackground(new Color(255, 135, 13));
		separator_Titulo.setBounds(178, 24, 2, 36);
		contentPane.add(separator_Titulo);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Cambiar_Contraseña.class.getResource("/Presentacion/imagenes/logo.png")));
		lblNewLabel.setBounds(27, 26, 151, 37);
		contentPane.add(lblNewLabel);
		
		lblCambiarContraseña = new JLabel("Cambiar contraseña");
		lblCambiarContraseña.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblCambiarContraseña.setBounds(188, 35, 113, 14);
		contentPane.add(lblCambiarContraseña);
		
		separator_Titulo_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1.setBounds(20, 91, 2, 290);
		contentPane.add(separator_Titulo_1);
		
		separator_Titulo_2 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_2.setForeground(new Color(255, 135, 13));
		separator_Titulo_2.setBackground(new Color(255, 135, 13));
		separator_Titulo_2.setBounds(414, 91, 2, 290);
		contentPane.add(separator_Titulo_2);
		
		txtContraseñaActualVisible = new JTextField();
		txtContraseñaActualVisible.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtContraseñaActualVisible.setBounds(144, 125, 151, 18);
		contentPane.add(txtContraseñaActualVisible);
		txtContraseñaActualVisible.setColumns(10);
		
		txtConfirmarContraseñaVisible = new JTextField();
		txtConfirmarContraseñaVisible.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtConfirmarContraseñaVisible.setBounds(144, 276, 151, 18);
		contentPane.add(txtConfirmarContraseñaVisible);
		txtConfirmarContraseñaVisible.setColumns(10);
		

	}
}
