package Presentacion;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class Cliente_Eliminar extends JFrame {

	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtApellido;
	private JTextField txtCedula;
	private JTextField txtTelefono;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	private static boolean esNumerico(String cadena) {
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException e) {          
        	return false;
        }
    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente_Eliminar frame = new Cliente_Eliminar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cliente_Eliminar() {
		setResizable(false);
		setTitle("Eliminar cliente");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Cliente_Registrar.class.getResource("/Presentacion/imagenes/cliente.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 481, 543);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNombre = new JTextField();
		txtNombre.setEditable(false);
		txtNombre.setBackground(Color.WHITE);
		txtNombre.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtNombre.setBounds(159, 181, 151, 18);
		contentPane.add(txtNombre);
		txtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtNombre.setColumns(10);
		
		JPanel panelNombre = new JPanel();
		panelNombre.setBackground(Color.WHITE);
		panelNombre.setBounds(153, 168, 163, 37);
		contentPane.add(panelNombre);
		TitledBorder Nombre = BorderFactory.createTitledBorder("Nombre");
		Nombre.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Nombre.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelNombre.setBorder(Nombre);
		getContentPane().add(panelNombre);
		
		txtApellido = new JTextField();
		txtApellido.setEditable(false);
		txtApellido.setBackground(Color.WHITE);
		txtApellido.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtApellido.setColumns(10);
		txtApellido.setBounds(159, 243, 151, 18);
		txtApellido.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtApellido);
		
		JPanel panelApellido = new JPanel();
		panelApellido.setBackground(Color.WHITE);
		panelApellido.setBounds(153, 230, 163, 37);
		contentPane.add(panelApellido);
		TitledBorder Apellido = BorderFactory.createTitledBorder("Apellido");
		Apellido.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Apellido.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelApellido.setBorder(Apellido);
		getContentPane().add(panelApellido);
		
		txtCedula = new JTextField();
		txtCedula.setBackground(Color.WHITE);
		txtCedula.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtCedula.setColumns(10);
		txtCedula.setBounds(159, 121, 151, 18);
		txtCedula.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtCedula);
		
		JPanel panelCedula = new JPanel();
		panelCedula.setBackground(Color.WHITE);
		panelCedula.setBounds(153, 107, 163, 38);
		contentPane.add(panelCedula);
		TitledBorder Cedula = BorderFactory.createTitledBorder("Cedula");
		Cedula.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Cedula.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelCedula.setBorder(Cedula);
		getContentPane().add(panelCedula);
		
		txtTelefono = new JTextField();
		txtTelefono.setEditable(false);
		txtTelefono.setBackground(Color.WHITE);
		txtTelefono.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(159, 307, 151, 18);
		txtTelefono.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtTelefono);
		
		JPanel panelTelefono = new JPanel();
		panelTelefono.setBackground(Color.WHITE);
		panelTelefono.setBounds(153, 294, 163, 37);
		contentPane.add(panelTelefono);
		TitledBorder Telefono = BorderFactory.createTitledBorder("Telefono");
		Telefono.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Telefono.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelTelefono.setBorder(Telefono);
		getContentPane().add(panelTelefono);
		
		txtEmail = new JTextField();
		txtEmail.setEditable(false);
		txtEmail.setBackground(Color.WHITE);
		txtEmail.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtEmail.setColumns(10);
		txtEmail.setBounds(159, 368, 151, 18);
		txtEmail.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtEmail);
		
		JPanel panelEmail = new JPanel();
		panelEmail.setBackground(Color.WHITE);
		panelEmail.setBounds(153, 355, 163, 37);
		contentPane.add(panelEmail);
		TitledBorder Email = BorderFactory.createTitledBorder("Email");
		Email.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Email.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelEmail.setBorder(Email);
		getContentPane().add(panelEmail);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			
			String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
			String usuario = "root";
		    String contrasena = "";        
		        
		    try {
				
				
			if (txtNombre.getText().length()>0) {
				
				if (txtApellido.getText().length()>0) {
				
					
				
							if (esNumerico(txtTelefono.getText())){
						
								if (Integer.parseInt(txtTelefono.getText())>1000000 && Integer.parseInt(txtTelefono.getText())<999999999) {
					
									if (txtEmail.getText().length()>0) {
										
										Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
		            					String consulta = "DELETE cliente SET nombre = ?, apellido = ?, telefono = ?, email = ? WHERE cedula = " + Integer.parseInt(txtCedula.getText());
		            					PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
	
		            					String nombre = txtNombre.getText();
		            					String apellido = txtApellido.getText();
		            					int telefono = Integer.parseInt(txtTelefono.getText());
		            					String email = txtEmail.getText();
		            					
			  
		            					preparedStatement.setString(1, nombre);
		            					preparedStatement.setString(2, apellido);
		            					preparedStatement.setInt(3, telefono);
		            					preparedStatement.setString(4, email);
	
		            					int filasEliminadas = preparedStatement.executeUpdate();
	
		            					if (filasEliminadas > 0) {
		            						JOptionPane.showMessageDialog(null, "Cliente eliminado exitosamente.", "Cliente eliminado", JOptionPane.INFORMATION_MESSAGE);
		            						txtNombre.setText("");
											txtApellido.setText("");
											txtCedula.setText("");
											txtTelefono.setText("");
											txtEmail.setText("");
		            						
		            					} else {
		            						JOptionPane.showMessageDialog(null, "No se pudo eliminar el cliente.", "Error", JOptionPane.ERROR_MESSAGE);
		            					}
		            					preparedStatement.close();
			    
		            					conexion.close();
		
									}else {
										JOptionPane.showMessageDialog(null, "Error en el email, no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
										txtNombre.setText("");
										txtApellido.setText("");
										txtCedula.setText("");
										txtTelefono.setText("");
										txtEmail.setText("");
									}
						
								}else {
									JOptionPane.showMessageDialog(null, "Error en el telefono, no es valido", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
									txtNombre.setText("");
									txtApellido.setText("");
									txtCedula.setText("");
									txtTelefono.setText("");
									txtEmail.setText("");
								}
						
							}else {
								JOptionPane.showMessageDialog(null, "Error en el telefono, no es numerico", "Error telefono", JOptionPane.ERROR_MESSAGE);
								txtNombre.setText("");
								txtApellido.setText("");
								txtCedula.setText("");
								txtTelefono.setText("");
								txtEmail.setText("");
							}
				
						
				}else {
					JOptionPane.showMessageDialog(null, "Error en el apellido, no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
					txtNombre.setText("");
					txtApellido.setText("");
               		txtTelefono.setText("");
               		txtEmail.setText("");
				}
			
			}else {
				JOptionPane.showMessageDialog(null, "Error en el nombre, no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
				txtNombre.setText("");
				txtApellido.setText("");
           		txtTelefono.setText("");
           		txtEmail.setText("");
			}
			
		    } catch (SQLException e1) {
        			if (e1.getMessage().contains("telefono")==true) {
	        			JOptionPane.showMessageDialog(null, "Error el telefono ya se encuentra registrado", "Error", JOptionPane.ERROR_MESSAGE);
	        			txtNombre.setText("");
	    				txtApellido.setText("");
	    				txtCedula.setText("");
               		    txtTelefono.setText("");
	               		txtEmail.setText("");
        			}else {
        				if (e1.getMessage().contains("email")==true) {
    	        			JOptionPane.showMessageDialog(null, "Error el email ya se encuentra registrado", "Error", JOptionPane.ERROR_MESSAGE);
    	        			txtNombre.setText("");
    	    				txtApellido.setText("");
    	    				txtCedula.setText("");
                   		    txtTelefono.setText("");
    	               		txtEmail.setText("");
        			}
		    	}	
			}
			}
			
		});
		btnEliminar.setBackground(Color.BLACK);
		btnEliminar.setForeground(Color.WHITE);
		btnEliminar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnEliminar.setBounds(153, 425, 163, 23);
		contentPane.add(btnEliminar);
		
		JLabel lblEliminarCliente = new JLabel("Eliminar Cliente");
		lblEliminarCliente.setHorizontalAlignment(SwingConstants.CENTER);
		lblEliminarCliente.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblEliminarCliente.setBounds(184, 33, 97, 14);
		contentPane.add(lblEliminarCliente);
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 60, 445, 19);
		contentPane.add(panel_NegroArriba);
		
		JSeparator separator_Titulo = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo.setForeground(new Color(255, 135, 13));
		separator_Titulo.setBackground(new Color(255, 135, 13));
		separator_Titulo.setBounds(180, 21, 2, 36);
		contentPane.add(separator_Titulo);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Cliente_Registrar.class.getResource("/Presentacion/imagenes/logo.png")));
		lblNewLabel.setBounds(30, 21, 150, 40);
		contentPane.add(lblNewLabel);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setLayout(null);
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(10, 477, 445, 19);
		contentPane.add(panel_NegroAbajo);
		
		JSeparator separator_Titulo_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1.setBounds(20, 90, 2, 376);
		contentPane.add(separator_Titulo_1);
		
		JSeparator separator_Titulo_1_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBounds(442, 90, 2, 376);
		contentPane.add(separator_Titulo_1_1);
		
		
		JButton btnBuscar = new JButton("Buscar");
		JButton btnNueva = new JButton("Nueva");
		btnNueva.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtCedula.setEnabled(true);
            	btnBuscar.setEnabled(true);
            	btnNueva.setEnabled(false);
				txtCedula.setText("");
				txtNombre.setText("");
				txtApellido.setText("");
				txtTelefono.setText("");
				txtEmail.setText("");
			}
		});
		
		btnNueva.setForeground(Color.WHITE);
		btnNueva.setBackground(Color.BLACK);
		btnNueva.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnNueva.setBounds(47, 118, 89, 23);
		contentPane.add(btnNueva);
		
		
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
				String usuario = "root";
			    String contrasena = "";      
				
				try {
					
					if (esNumerico(txtCedula.getText())){
						
						if (Integer.parseInt(txtCedula.getText())>1000000 && Integer.parseInt(txtCedula.getText())<70000000){
					
					Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
					Statement statement = (Statement) conexion.createStatement();
		            String consulta = "SELECT nombre, apellido, telefono, email FROM cliente WHERE cedula = " + Integer.parseInt(txtCedula.getText());
		           
		         
		            ResultSet resultSet = statement.executeQuery(consulta);
		            
		            
		            int cant_filas=0;
		            String nombre=null;
		            String apellido=null;
		            String telefono=null;
		            String email=null;

		            
		            while(resultSet.next()){
		            	nombre=resultSet.getString("nombre");
		            	apellido=resultSet.getString("apellido");
		            	telefono=resultSet.getString("telefono");
		            	email=resultSet.getString("email");
		            	cant_filas++;
		            }
		            statement.close();
		            conexion.close();
		            
		            if(cant_filas>0) {
		            	
		            	txtNombre.setText(nombre);
		            	txtApellido.setText(apellido);
		            	txtTelefono.setText(telefono);
		            	txtEmail.setText(email);
		            	txtCedula.setEnabled(false);
		            	btnBuscar.setEnabled(false);
		            	btnNueva.setEnabled(true);
		            	
		            }else {
		            	JOptionPane.showMessageDialog(null, "El cliente no existe.", "Cliente no existe", JOptionPane.INFORMATION_MESSAGE);
		            	txtCedula.setText("");
		            }
		            
		            }else {
						JOptionPane.showMessageDialog(null, "Error en la cedula, no es valida", "Error", JOptionPane.ERROR_MESSAGE);		        	
						txtNombre.setText("");
						txtApellido.setText("");
						txtCedula.setText("");
						txtTelefono.setText("");
						txtEmail.setText("");
					}
			
				}else {
					JOptionPane.showMessageDialog(null, "Error en la cedula, no es numerica", "Error cedula", JOptionPane.ERROR_MESSAGE);
					txtNombre.setText("");
					txtApellido.setText("");
					txtCedula.setText("");
					txtTelefono.setText("");
					txtEmail.setText("");
				}
		 
		        } catch (SQLException e1) {
		        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage());
		        }
				
				
			}
		});
		
		btnBuscar.setForeground(Color.WHITE);
		btnBuscar.setBackground(Color.BLACK);
		btnBuscar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnBuscar.setBounds(320, 118, 89, 23);
		contentPane.add(btnBuscar);
		
		
		
	}
}
