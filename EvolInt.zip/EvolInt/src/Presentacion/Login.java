package Presentacion;


import java.awt.EventQueue;



import javax.swing.JFrame;
import net.miginfocom.swing.MigLayout;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.mysql.jdbc.Statement;
import com.jgoodies.forms.layout.FormSpecs;
import javax.swing.SpringLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Window.Type;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import java.awt.Scrollbar;

import javax.swing.BorderFactory;
import javax.swing.DropMode;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

 

public class Login {

	private JFrame frm;
	private JTextField txtUsuario;
	private JPasswordField txtContraseña;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frm.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
		
	}

	
	private void loguearse() {
		
		String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
        String usuario = "root";
        String contrasena = "";        
        
		try {
		
	// Si nombre de usuario sea un largo mayor = 5
		if(txtUsuario.getText().length()>=5) {
		// Contraseña mayor o igual a 8
			if (txtContraseña.getText().length()>=8) {
				
				Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
	            // Crear una declaración
				Statement statement = (Statement) conexion.createStatement();
				String consulta = "SELECT tipo_usuario FROM usuario WHERE nombre_usuario='" + txtUsuario.getText() + "' AND AES_DECRYPT(contraseña, 'EvolInt_Proyecto')='" + txtContraseña.getText() + "'";

				ResultSet resultSet = statement.executeQuery(consulta);
				
				int cant_filas=0;
				String tipo_usuario=null;
				
	            while (resultSet.next()) {
	            	tipo_usuario=resultSet.getString("tipo_usuario");
	            	cant_filas++;
	            	}
	            //Cierro Conexiones
            	resultSet.close();
        	 	statement.close();
        	 	conexion.close();

	            //Si cant_filas es mayor existe un registro al menos.
	            if (cant_filas>0) {
	            		switch (tipo_usuario) {
	            		case "Administrador":
	            			Menu fromMenuAdm = new Menu("Administrador",txtUsuario.getText());
	        				fromMenuAdm.setVisible(true);
	        				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	        			    int xA = (screenSize.width - fromMenuAdm.getWidth()) / 2;
	        		        int yA = (screenSize.height - fromMenuAdm.getHeight()) / 2;
	        		        fromMenuAdm.setLocation(xA, yA);
	        				//cierro ventana login
	        				frm.dispose();
	        				break;
	        				
	            		case "Usuario":
	            			Menu fromMenuUsu = new Menu("Usuario",txtUsuario.getText());
	        				fromMenuUsu.setVisible(true);
	        				Dimension screenSizeU = Toolkit.getDefaultToolkit().getScreenSize();
	        			    int xU = (screenSizeU.width - fromMenuUsu.getWidth()) / 2;
	        		        int yU = (screenSizeU.height - fromMenuUsu.getHeight()) / 2;
	        		        fromMenuUsu.setLocation(xU, yU);
	        				//cierro ventana login
	        				frm.dispose();
	        				break;
	            		default: break;
	            		}
	            	
	            } else {
	            	JOptionPane.showMessageDialog(null, "Nombre de usuario o contraseña incorrectas", "Error", JOptionPane.ERROR_MESSAGE); 	
	            	txtUsuario.setText("");
					txtContraseña.setText("");
					txtUsuario.requestFocus();
	            }
	      

		}else {
			JOptionPane.showMessageDialog(null, "Error la contraseña debe contener 8 caracteres como minimo", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
			txtUsuario.setText("");
			txtContraseña.setText("");
			txtUsuario.requestFocus();
		}
			
		}else {
			JOptionPane.showMessageDialog(null, "Error el nombre de usuario debe contener 5 caracteres como minimo", "Error", JOptionPane.INFORMATION_MESSAGE);
        	txtUsuario.setText("");
       		txtContraseña.setText("");
       		txtUsuario.requestFocus();
		}
		
		} catch (SQLException e1) {
        	JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }	
		
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
 	private void initialize() {
		frm = new JFrame();
		
		
		frm.getContentPane().setBackground(Color.WHITE);
		frm.setFont(null);
		frm.setTitle("Login");
		frm.getContentPane().setForeground(new Color(0, 0, 0));
		frm.setResizable(false);
		frm.setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/Presentacion/imagenes/icono_app.png")));
	    frm.setSize(359, 387);
	    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (screenSize.width - frm.getWidth()) / 2;
        int y = (screenSize.height - frm.getHeight()) / 2;
        frm.setLocation(x, y);
		frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frm.getContentPane().setLayout(null);
		
		JLabel lblLogo = new JLabel("");
		lblLogo.setBounds(0, 47, 343, 60);
		frm.getContentPane().add(lblLogo);
		lblLogo.setIcon(new ImageIcon(Login.class.getResource("/Presentacion/imagenes/logo.png")));
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtUsuario = new JTextField();
		txtUsuario.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					loguearse();
				}
			}
			
		});
		txtUsuario.setBackground(Color.WHITE);
		txtUsuario.setBounds(93, 145, 151, 18);
		frm.getContentPane().add(txtUsuario);
		txtUsuario.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtUsuario.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtUsuario.setToolTipText("");
		txtUsuario.setColumns(342);
		
		JPanel panel_Usuario = new JPanel();
		panel_Usuario.setBackground(Color.WHITE);
		panel_Usuario.setBounds(87, 132, 163, 37);
		frm.getContentPane().add(panel_Usuario);
		
		TitledBorder Usuario = BorderFactory.createTitledBorder("Usuario");
		Usuario.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Usuario.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panel_Usuario.setBorder(Usuario);
		frm.getContentPane().add(panel_Usuario);
		
		txtContraseña = new JPasswordField();
		txtContraseña.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					loguearse();
				}
			}
		});
		txtContraseña.setBackground(Color.WHITE);
		txtContraseña.setBounds(93, 203, 151, 18);
		frm.getContentPane().add(txtContraseña);
		txtContraseña.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.setBounds(87, 262, 157, 23);
		frm.getContentPane().add(btnIngresar);
		btnIngresar.setMnemonic('I');
		btnIngresar.setBackground(Color.BLACK);
		btnIngresar.setForeground(Color.WHITE);
		btnIngresar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		
		JPanel panel_Contraseña = new JPanel();
		panel_Contraseña.setBackground(Color.WHITE);
		panel_Contraseña.setBounds(87, 190, 163, 37);
		frm.getContentPane().add(panel_Contraseña);
		
		TitledBorder Contraseña = BorderFactory.createTitledBorder("Contraseña");
		Contraseña.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Contraseña.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panel_Contraseña.setBorder(Contraseña);
		frm.getContentPane().add(panel_Contraseña);
		
		
		
		btnIngresar.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				loguearse();	
			}
		});
	}
}




