package Presentacion;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;



public class Cliente_Registrar extends JFrame {

	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField txtApellido;
	private JTextField txtCedula;
	private JTextField txtTelefono;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	
	private static boolean esNumerico(String cadena) {
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException e) {          
        	return false;
        }
    }
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente_Registrar frame = new Cliente_Registrar();
					frame.setVisible(true);
					 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					    int x = (screenSize.width - frame.getWidth()) / 2;
				        int y = (screenSize.height - frame.getHeight()) / 2;
				        frame.setLocation(x, y);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cliente_Registrar() {
		setResizable(false);
		setTitle("Registrar cliente");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Cliente_Registrar.class.getResource("/Presentacion/imagenes/cliente.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 481, 543);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNombre = new JTextField();
		txtNombre.setBackground(Color.WHITE);
		txtNombre.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtNombre.setBounds(159, 181, 151, 18);
		contentPane.add(txtNombre);
		txtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtNombre.setColumns(10);
		
		JPanel panelNombre = new JPanel();
		panelNombre.setBackground(Color.WHITE);
		panelNombre.setBounds(153, 168, 163, 37);
		contentPane.add(panelNombre);
		TitledBorder Nombre = BorderFactory.createTitledBorder("Nombre");
		Nombre.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Nombre.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelNombre.setBorder(Nombre);
		getContentPane().add(panelNombre);
		
		txtApellido = new JTextField();
		txtApellido.setBackground(Color.WHITE);
		txtApellido.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtApellido.setColumns(10);
		txtApellido.setBounds(159, 243, 151, 18);
		txtApellido.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtApellido);
		
		JPanel panelApellido = new JPanel();
		panelApellido.setBackground(Color.WHITE);
		panelApellido.setBounds(153, 230, 163, 37);
		contentPane.add(panelApellido);
		TitledBorder Apellido = BorderFactory.createTitledBorder("Apellido");
		Apellido.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Apellido.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelApellido.setBorder(Apellido);
		getContentPane().add(panelApellido);
		
		txtCedula = new JTextField();
		txtCedula.setBackground(Color.WHITE);
		txtCedula.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtCedula.setColumns(10);
		txtCedula.setBounds(159, 121, 151, 18);
		txtCedula.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtCedula);
		
		JPanel panelCedula = new JPanel();
		panelCedula.setBackground(Color.WHITE);
		panelCedula.setBounds(153, 107, 163, 38);
		contentPane.add(panelCedula);
		TitledBorder Cedula = BorderFactory.createTitledBorder("Cedula");
		Cedula.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Cedula.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelCedula.setBorder(Cedula);
		getContentPane().add(panelCedula);
		
		txtTelefono = new JTextField();
		txtTelefono.setBackground(Color.WHITE);
		txtTelefono.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtTelefono.setColumns(10);
		txtTelefono.setBounds(159, 307, 151, 18);
		txtTelefono.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtTelefono);
		
		JPanel panelTelefono = new JPanel();
		panelTelefono.setBackground(Color.WHITE);
		panelTelefono.setBounds(153, 294, 163, 37);
		contentPane.add(panelTelefono);
		TitledBorder Telefono = BorderFactory.createTitledBorder("Telefono");
		Telefono.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Telefono.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelTelefono.setBorder(Telefono);
		getContentPane().add(panelTelefono);
		
		txtEmail = new JTextField();
		txtEmail.setBackground(Color.WHITE);
		txtEmail.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		txtEmail.setColumns(10);
		txtEmail.setBounds(159, 368, 151, 18);
		txtEmail.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		contentPane.add(txtEmail);
		
		JPanel panelEmail = new JPanel();
		panelEmail.setBackground(Color.WHITE);
		panelEmail.setBounds(153, 355, 163, 37);
		contentPane.add(panelEmail);
		TitledBorder Email = BorderFactory.createTitledBorder("Email");
		Email.setTitleFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11)); // Cambiar la fuente y el estilo
		Email.setBorder(BorderFactory.createLineBorder(new Color(255, 135, 13))); // Cambiar el borde del título
		
		panelEmail.setBorder(Email);
		getContentPane().add(panelEmail);
		
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			
			String url = "jdbc:mysql://localhost/evolint_nellyrodríguez";
			String usuario = "root";
		    String contrasena = "";        
		        
		    try {
				
				
			if (txtNombre.getText().length()>0) {
				
				if (txtApellido.getText().length()>0) {
				
					if (esNumerico(txtCedula.getText())){
				
						if (Integer.parseInt(txtCedula.getText())>1000000 && Integer.parseInt(txtCedula.getText())<70000000){
				
							if (esNumerico(txtTelefono.getText())){
						
								if (Integer.parseInt(txtTelefono.getText())>1000000 && Integer.parseInt(txtTelefono.getText())<999999999) {
					
									if (txtEmail.getText().length()>0) {
										
										Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
		            					String consulta = "INSERT INTO cliente VALUES (?, ?, ?, ?, ?)";
		            					PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
	
		            					int cedula = Integer.parseInt(txtCedula.getText());
		            					String nombre = txtNombre.getText();
		            					String apellido = txtApellido.getText();
		            					int telefono = Integer.parseInt(txtTelefono.getText());
		            					String email = txtEmail.getText();
		            					
			   
		            					preparedStatement.setInt(1, cedula);
		            					preparedStatement.setString(2, nombre);
		            					preparedStatement.setString(3, apellido);
		            					preparedStatement.setInt(4, telefono);
		            					preparedStatement.setString(5, email);
	
		            					int filasInsertadas = preparedStatement.executeUpdate();
	
		            					if (filasInsertadas > 0) {
		            						JOptionPane.showMessageDialog(null, "Cliente registrado exitosamente.", "Cliente creado", JOptionPane.INFORMATION_MESSAGE);
		            						txtNombre.setText("");
											txtApellido.setText("");
											txtCedula.setText("");
											txtTelefono.setText("");
											txtEmail.setText("");
		            						
		            					} else {
		            						JOptionPane.showMessageDialog(null, "No se pudo insertar el registro.", "Error", JOptionPane.ERROR_MESSAGE);
		            					}
		            					preparedStatement.close();
			    
		            					conexion.close();
		
									}else {
										JOptionPane.showMessageDialog(null, "Error en el email, no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
										txtNombre.setText("");
										txtApellido.setText("");
										txtCedula.setText("");
										txtTelefono.setText("");
										txtEmail.setText("");
									}
						
								}else {
									JOptionPane.showMessageDialog(null, "Error en el telefono, no es valido", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
									txtNombre.setText("");
									txtApellido.setText("");
									txtCedula.setText("");
									txtTelefono.setText("");
									txtEmail.setText("");
								}
						
							}else {
								JOptionPane.showMessageDialog(null, "Error en el telefono, no es numerico", "Error telefono", JOptionPane.ERROR_MESSAGE);
								txtNombre.setText("");
								txtApellido.setText("");
								txtCedula.setText("");
								txtTelefono.setText("");
								txtEmail.setText("");
							}
				
						}else {
							JOptionPane.showMessageDialog(null, "Error en la cedula, no es valida", "Error", JOptionPane.ERROR_MESSAGE);		        	
							txtNombre.setText("");
							txtApellido.setText("");
							txtCedula.setText("");
							txtTelefono.setText("");
							txtEmail.setText("");
						}
				
					}else {
						JOptionPane.showMessageDialog(null, "Error en la cedula, no es numerica", "Error cedula", JOptionPane.ERROR_MESSAGE);
						txtNombre.setText("");
						txtApellido.setText("");
						txtCedula.setText("");
						txtTelefono.setText("");
						txtEmail.setText("");
					}
			
				}else {
					JOptionPane.showMessageDialog(null, "Error en el apellido, no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
					txtNombre.setText("");
					txtApellido.setText("");
					txtCedula.setText("");
               		txtTelefono.setText("");
               		txtEmail.setText("");
				}
			
			}else {
				JOptionPane.showMessageDialog(null, "Error en el nombre, no puede ser vacio", "Error", JOptionPane.INFORMATION_MESSAGE);		        	
				txtNombre.setText("");
				txtApellido.setText("");
				txtCedula.setText("");
           		txtTelefono.setText("");
           		txtEmail.setText("");
			}
			
		    } catch (SQLException e1) {
		    	if (e1.getMessage().contains("PRIMARY")==true) {
        			JOptionPane.showMessageDialog(null, "Error la cédula ya se encuentra registrada.", "Error", JOptionPane.ERROR_MESSAGE);
        			txtNombre.setText("");
    				txtApellido.setText("");
    				txtCedula.setText("");
               		txtTelefono.setText("");
               		txtEmail.setText("");      
               		
		    	}else {
        			if (e1.getMessage().contains("telefono")==true) {
	        			JOptionPane.showMessageDialog(null, "Error el telefono ya se encuentra registrado", "Error", JOptionPane.ERROR_MESSAGE);
	        			txtNombre.setText("");
	    				txtApellido.setText("");
	    				txtCedula.setText("");
               		    txtTelefono.setText("");
	               		txtEmail.setText("");
        			}else {
        				if (e1.getMessage().contains("email")==true) {
    	        			JOptionPane.showMessageDialog(null, "Error el email ya se encuentra registrado", "Error", JOptionPane.ERROR_MESSAGE);
    	        			txtNombre.setText("");
    	    				txtApellido.setText("");
    	    				txtCedula.setText("");
                   		    txtTelefono.setText("");
    	               		txtEmail.setText("");
        			}
		    	}	
		    }
			}
			}
			
		});
		btnIngresar.setBackground(Color.BLACK);
		btnIngresar.setForeground(Color.WHITE);
		btnIngresar.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		btnIngresar.setMnemonic('I');
		btnIngresar.setBounds(153, 425, 163, 23);
		contentPane.add(btnIngresar);
		
		JLabel lblRegistrarCliente = new JLabel("Registrar Cliente");
		lblRegistrarCliente.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistrarCliente.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 11));
		lblRegistrarCliente.setBounds(184, 33, 97, 14);
		contentPane.add(lblRegistrarCliente);
		
		JPanel panel_NegroArriba = new JPanel();
		panel_NegroArriba.setLayout(null);
		panel_NegroArriba.setBackground(Color.BLACK);
		panel_NegroArriba.setBounds(10, 60, 445, 19);
		contentPane.add(panel_NegroArriba);
		
		JSeparator separator_Titulo = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo.setForeground(new Color(255, 135, 13));
		separator_Titulo.setBackground(new Color(255, 135, 13));
		separator_Titulo.setBounds(180, 21, 2, 36);
		contentPane.add(separator_Titulo);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Cliente_Registrar.class.getResource("/Presentacion/imagenes/logo.png")));
		lblNewLabel.setBounds(30, 21, 150, 40);
		contentPane.add(lblNewLabel);
		
		JPanel panel_NegroAbajo = new JPanel();
		panel_NegroAbajo.setLayout(null);
		panel_NegroAbajo.setBackground(Color.BLACK);
		panel_NegroAbajo.setBounds(10, 477, 445, 19);
		contentPane.add(panel_NegroAbajo);
		
		JSeparator separator_Titulo_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1.setBounds(20, 90, 2, 376);
		contentPane.add(separator_Titulo_1);
		
		JSeparator separator_Titulo_1_1 = new JSeparator(SwingConstants.VERTICAL);
		separator_Titulo_1_1.setForeground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBackground(new Color(255, 135, 13));
		separator_Titulo_1_1.setBounds(442, 90, 2, 376);
		contentPane.add(separator_Titulo_1_1);
		
	}
}
